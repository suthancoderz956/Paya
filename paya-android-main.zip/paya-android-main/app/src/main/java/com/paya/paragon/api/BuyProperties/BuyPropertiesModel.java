package com.paya.paragon.api.BuyProperties;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.paya.paragon.api.propertyDetails.PropertyDetailsModel;

import java.io.Serializable;
import java.util.List;

@SuppressWarnings("unused")
public class BuyPropertiesModel implements Serializable {
    @SerializedName("propertyUnitPriceRange")
    private String propertyUnitPriceRange;
    @SerializedName("isNegotiable")
    private String isNegotiable;
    @SerializedName("pricePerSqft")
    private String pricePerSqft;
    @SerializedName("propertyName")
    private String propertyName;
    @SerializedName("cityLocName")
    private String cityLocName;
    @SerializedName("propertyAddedDate")
    private String propertyAddedDate;
    @SerializedName("propertyCoverImage")
    private String propertyCoverImage;
    @SerializedName("proLatitude")
    private String proLatitude;
    @SerializedName("proLongitude")
    private String proLongitude;
    @SerializedName("propertyID")
    private String propertyID;
    @SerializedName("propertyFeatured")
    private String propertyFeatured;
    @SerializedName("propertyFavourite")
    private String propertyFavourite;
    @SerializedName("type")
    private String type;
    @SerializedName("propertyplanEnquiryCountBalance")
    private String propertyplanEnquiryCountBalance;
    @SerializedName("projectUserCompanyName")
    private String projectUserCompanyName;
    @SerializedName("projectUserCompanyLogo")
    private String projectUserCompanyLogo;
    @SerializedName("propertyBedRoom")
    private String projectBedRoom;
    @SerializedName("propertyPrice")
    private String propertyPrice;
    @SerializedName("propertySqrFeet")
    private String propertySqrFeet;
    @SerializedName("propertyPlotArea")
    private String propertyPlotArea;
    @SerializedName("propertyTypeName")
    private String projectTypeName;
    @SerializedName("projectName")
    private String projectName;
    @SerializedName("projectAddedDate")
    private String projectAddedDate;
    @SerializedName("projectCoverImage")
    private String projectCoverImage;
    @SerializedName("projectBuilderName")
    private String projectBuilderName;
    @SerializedName("projectID")
    private String projectID;
    @SerializedName("projectFeatured")
    private String projectFeatured;
    @SerializedName("projectFavourite")
    private String projectFavourite;
    @SerializedName("imageCount")
    private String imageCount;
    @SerializedName("link")
    private String link;
    @SerializedName("pricePerUnitValue")
    private String pricePerUnitValue;
    @SerializedName("pricePerUnit")
    private String pricePerUnit;
    @SerializedName("exact")
    private String exact;
    @SerializedName("propertySoldOutStatus")
    private String propertySoldOutStatus;
    @SerializedName("propertySoldOutPrice")
    private String propertySoldOutPrice;
    @SerializedName("propertySoldOutDate")
    private String propertySoldOutDate;
    @SerializedName("propertyTypeIcon")
    private String propertyTypeIcon;
    @SerializedName("propertyBathRoom")
    private String propertyBathRoom;
    @SerializedName("isOffer")
    private String isOffer;
    @SerializedName("propertyOfferPrice")
    private String propertyOfferPrice;
    @SerializedName("propertyOfferDiscount")
    private String propertyOfferDiscount;
    @SerializedName("currencyID_1")
    private String currencyID_1;
    @SerializedName("currencyID_5")
    private String currencyID_5;
    @SerializedName("images")
    @Expose private List<ImagesList> images;

    public List<ImagesList> getImages() {
        return images;
    }

    public void setImages(List<ImagesList> images) {
        this.images = images;
    }

    public String getIsOffer() {
        return isOffer;
    }

    public void setIsOffer(String isOffer) {
        this.isOffer = isOffer;
    }

    public String getPropertyOfferPrice() {
        return propertyOfferPrice;
    }

    public void setPropertyOfferPrice(String propertyOfferPrice) {
        this.propertyOfferPrice = propertyOfferPrice;
    }

    public String getPropertyOfferDiscount() {
        return propertyOfferDiscount;
    }

    public void setPropertyOfferDiscount(String propertyOfferDiscount) {
        this.propertyOfferDiscount = propertyOfferDiscount;
    }

    public String getPropertyTypeIcon() {
        return propertyTypeIcon;
    }

    public void setPropertyTypeIcon(String propertyTypeIcon) {
        this.propertyTypeIcon = propertyTypeIcon;
    }

    public String getPropertyBathRoom() {
        return propertyBathRoom;
    }

    public void setPropertyBathRoom(String propertyBathRoom) {
        this.propertyBathRoom = propertyBathRoom;
    }

    public String getImageCount() {
        return imageCount;
    }

    public void setImageCount(String imageCount) {
        this.imageCount = imageCount;
    }

    public String getPropertyplanEnquiryCountBalance() {
        return propertyplanEnquiryCountBalance;
    }

    public void setPropertyplanEnquiryCountBalance(String propertyplanEnquiryCountBalance) {
        this.propertyplanEnquiryCountBalance = propertyplanEnquiryCountBalance;
    }

    public String getPropertySqrFeet() {
        return propertySqrFeet;
    }

    public String getPropertyPrice() {
        return propertyPrice;
    }

    public void setPropertyPrice(String propertyPrice) {
        this.propertyPrice = propertyPrice;
    }

    public void setPropertySqrFeet(String propertySqrFeet) {
        this.propertySqrFeet = propertySqrFeet;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getProjectUserCompanyName() {
        return projectUserCompanyName;
    }

    public void setProjectUserCompanyName(String projectUserCompanyName) {
        this.projectUserCompanyName = projectUserCompanyName;
    }

    public String getPropertyUnitPriceRange() {
        return propertyUnitPriceRange;
    }

    public void setPropertyUnitPriceRange(String propertyUnitPriceRange) {
        this.propertyUnitPriceRange = propertyUnitPriceRange;
    }

    public String getIsNegotiable() {
        return isNegotiable;
    }

    public void setIsNegotiable(String isNegotiable) {
        this.isNegotiable = isNegotiable;
    }

    public String getPricePerSqft() {
        return pricePerSqft;
    }

    public void setPricePerSqft(String pricePerSqft) {
        this.pricePerSqft = pricePerSqft;
    }

    public String getPropertyName() {
        return propertyName;
    }

    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }

    public String getCityLocName() {
        return cityLocName;
    }

    public void setCityLocName(String cityLocName) {
        this.cityLocName = cityLocName;
    }

    public String getPropertyAddedDate() {
        return propertyAddedDate;
    }

    public void setPropertyAddedDate(String propertyAddedDate) {
        this.propertyAddedDate = propertyAddedDate;
    }

    public String getPropertyCoverImage() {
        return propertyCoverImage;
    }

    public void setPropertyCoverImage(String propertyCoverImage) {
        this.propertyCoverImage = propertyCoverImage;
    }

    public String getProLatitude() {
        return proLatitude;
    }

    public void setProLatitude(String proLatitude) {
        this.proLatitude = proLatitude;
    }

    public String getProLongitude() {
        return proLongitude;
    }

    public void setProLongitude(String proLongitude) {
        this.proLongitude = proLongitude;
    }

    public String getPropertyID() {
        return propertyID;
    }

    public void setPropertyID(String propertyID) {
        this.propertyID = propertyID;
    }

    public String getPropertyFeatured() {
        return propertyFeatured;
    }

    public void setPropertyFeatured(String propertyFeatured) {
        this.propertyFeatured = propertyFeatured;
    }

    public String getPropertyFavourite() {
        return propertyFavourite;
    }

    public void setPropertyFavourite(String propertyFavourite) {
        this.propertyFavourite = propertyFavourite;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getProjectBedRoom() {
        return projectBedRoom;
    }

    public void setProjectBedRoom(String projectBedRoom) {
        this.projectBedRoom = projectBedRoom;
    }

    public String getProjectTypeName() {
        return projectTypeName;
    }

    public void setProjectTypeName(String projectTypeName) {
        this.projectTypeName = projectTypeName;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getProjectAddedDate() {
        return projectAddedDate;
    }

    public void setProjectAddedDate(String projectAddedDate) {
        this.projectAddedDate = projectAddedDate;
    }

    public String getProjectCoverImage() {
        return projectCoverImage;
    }

    public void setProjectCoverImage(String projectCoverImage) {
        this.projectCoverImage = projectCoverImage;
    }

    public String getProjectBuilderName() {
        return projectBuilderName;
    }

    public void setProjectBuilderName(String projectBuilderName) {
        this.projectBuilderName = projectBuilderName;
    }

    public String getProjectID() {
        return projectID;
    }

    public void setProjectID(String projectID) {
        this.projectID = projectID;
    }

    public String getProjectFeatured() {
        return projectFeatured;
    }

    public void setProjectFeatured(String projectFeatured) {
        this.projectFeatured = projectFeatured;
    }

    public String getProjectFavourite() {
        return projectFavourite;
    }

    public void setProjectFavourite(String projectFavourite) {
        this.projectFavourite = projectFavourite;
    }

    public String getPropertyPlotArea() {
        return propertyPlotArea;
    }

    public void setPropertyPlotArea(String propertyPlotArea) {
        this.propertyPlotArea = propertyPlotArea;
    }

    public String getPricePerUnitValue() {
        return pricePerUnitValue;
    }

    public void setPricePerUnitValue(String pricePerUnitValue) {
        this.pricePerUnitValue = pricePerUnitValue;
    }

    public String getPricePerUnit() {
        return pricePerUnit;
    }

    public void setPricePerUnit(String pricePerUnit) {
        this.pricePerUnit = pricePerUnit;
    }

    public String getExact() {
        return exact;
    }

    public void setExact(String exact) {
        this.exact = exact;
    }

    public String getPropertySoldOutStatus() {
        return propertySoldOutStatus;
    }

    public void setPropertySoldOutStatus(String propertySoldOutStatus) {
        this.propertySoldOutStatus = propertySoldOutStatus;
    }

    public String getPropertySoldOutPrice() {
        return propertySoldOutPrice;
    }

    public void setPropertySoldOutPrice(String propertySoldOutPrice) {
        this.propertySoldOutPrice = propertySoldOutPrice;
    }

    public String getPropertySoldOutDate() {
        return propertySoldOutDate;
    }

    public void setPropertySoldOutDate(String propertySoldOutDate) {
        this.propertySoldOutDate = propertySoldOutDate;
    }

    public String getProjectUserCompanyLogo() {
        return projectUserCompanyLogo;
    }

    public void setProjectUserCompanyLogo(String projectUserCompanyLogo) {
        this.projectUserCompanyLogo = projectUserCompanyLogo;
    }

    public String getCurrencyID_1() {
        return currencyID_1;
    }

    public void setCurrencyID_1(String currencyID_1) {
        this.currencyID_1 = currencyID_1;
    }

    public String getCurrencyID_5() {
        return currencyID_5;
    }

    public void setCurrencyID_5(String currencyID_5) {
        this.currencyID_5 = currencyID_5;
    }
}
