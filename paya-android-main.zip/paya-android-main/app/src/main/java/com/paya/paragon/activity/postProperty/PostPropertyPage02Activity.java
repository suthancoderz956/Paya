package com.paya.paragon.activity.postProperty;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.ViewModelProviders;

import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.paya.paragon.R;
import com.paya.paragon.databinding.ActivityPostPropertyPage02Binding;
import com.paya.paragon.utilities.AppConstant;
import com.paya.paragon.utilities.Utils;
import com.paya.paragon.viewmodel.PostPropertyViewModel;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class  PostPropertyPage02Activity extends AppCompatActivity implements OnMapReadyCallback,
        GoogleMap.OnCameraMoveStartedListener,
        GoogleMap.OnCameraMoveListener,
        GoogleMap.OnCameraMoveCanceledListener,
        GoogleMap.OnCameraIdleListener {

    private SupportMapFragment supportMapFragment;
    private FusedLocationProviderClient fusedLocationProviderClient;
    private GoogleMap googleMap;
    private LocationRequest locationRequest;

    private int PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 101;
    private int REQUEST_CHECK_SETTINGS = 101;

    private ActivityPostPropertyPage02Binding binding;


    @Override
    protected void onCreate(@Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_post_property_page_02);
        binding.setActivity(this);
        setMapFragment();
    }
    @Override
    protected void onResume() {
        super.onResume();
        Utils.changeLayoutOrientationDynamically(this, binding.cl02Parent);
    }

    private void setMapFragment() {
        supportMapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        supportMapFragment.getMapAsync(this);
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
    }

    @Override
    public void onMapReady(GoogleMap map) {
        googleMap = map;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this.getApplicationContext(),
                    android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                googleMap.setMyLocationEnabled(true);
                googleMap.getUiSettings().setMapToolbarEnabled(true);
                googleMap.getUiSettings().setMyLocationButtonEnabled(true);
                checkLocationService();
            } else {
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                        PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION
                );
            }
        } else {
            googleMap.setMyLocationEnabled(true);
            googleMap.getUiSettings().setMapToolbarEnabled(true);
            googleMap.getUiSettings().setMyLocationButtonEnabled(true);
            checkLocationService();
        }

        googleMap.setOnCameraMoveStartedListener(this);
        googleMap.setOnCameraIdleListener(this);
        googleMap.setOnCameraMoveListener(this);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull @NotNull String[] permissions, @NonNull @NotNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (ContextCompat.checkSelfPermission(this.getApplicationContext(),
                android.Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            googleMap.setMyLocationEnabled(true);
            googleMap.getUiSettings().setMapToolbarEnabled(true);
            googleMap.getUiSettings().setMyLocationButtonEnabled(true);
            checkLocationService();
        }
    }

    private void fetchCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                    PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION
            );
            return;
        } else {
            fusedLocationProviderClient.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() {
                @Override
                public void onSuccess(Location location) {
                    if (location != null) {
                        LatLng currentLatLng = new LatLng(location.getLatitude(), location.getLongitude());
                        if (PostPropertyPage01Activity.m_PostPropertyAPIData.getPropertyLatitude() != null &&
                                PostPropertyPage01Activity.m_PostPropertyAPIData.getPropertyLongitude() != null) {
                            currentLatLng = new LatLng(Double.parseDouble(PostPropertyPage01Activity.m_PostPropertyAPIData.getPropertyLatitude()),
                                    Double.parseDouble(PostPropertyPage01Activity.m_PostPropertyAPIData.getPropertyLongitude()));
                        }
                        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 8f));
                    }
                }
            });
        }
    }

    private void checkLocationService() {
        locationRequest = LocationRequest.create();
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        locationRequest.setInterval(10 * 1000);
        locationRequest.setFastestInterval(2 * 1000);


        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder().addLocationRequest(locationRequest);
        builder.setAlwaysShow(true);
        SettingsClient client = LocationServices.getSettingsClient(this);
        Task<LocationSettingsResponse> task = client.checkLocationSettings(builder.build());
        task.addOnSuccessListener(new OnSuccessListener<LocationSettingsResponse>() {
            @Override
            public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                locationSettingsResponse.getLocationSettingsStates();
                fetchCurrentLocation();
            }
        });

        task.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull @NotNull Exception e) {
                if (e instanceof ResolvableApiException) {
                    try {
                        ((ResolvableApiException) e).startResolutionForResult(PostPropertyPage02Activity.this, REQUEST_CHECK_SETTINGS);
                    } catch (Exception ex) {
                        FirebaseCrashlytics.getInstance().recordException(e);
                    }
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable @org.jetbrains.annotations.Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CHECK_SETTINGS) {
            if (resultCode == Activity.RESULT_OK) {
                fetchCurrentLocation();
            } else if (resultCode == Activity.RESULT_CANCELED) {
                //Write your code if there's no result
            }
        }
    }

    @Override
    public void onCameraMoveStarted(int i) {
        if(googleMap != null){
            googleMap.clear();
        }
    }

    @Override
    public void onCameraIdle() {
        LatLng latLng = googleMap.getCameraPosition().target;
        getAddressUsingLatLong(latLng.latitude, latLng.longitude);
    }

    private void getAddressUsingLatLong(double latitude, double longitude) {
        Geocoder geocoder;
        List<Address> addresses;
        geocoder = new Geocoder(this, Locale.getDefault());
        try {
            addresses = geocoder.getFromLocation(latitude, longitude, 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
            if (!addresses.isEmpty()) {
                for (Address address : addresses) {
                    setAddressFromMap(address, latitude, longitude);
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void setAddressFromMap(Address address, double latitude, double longitude) {
        PostPropertyPage01Activity.m_PostPropertyAPIData.setGoogleSearchText(address.getLocality());
        PostPropertyPage01Activity.m_PostPropertyAPIData.setGoogleLocality(address.getLocality());
        if (address.getAdminArea() != null &&
                address.getSubAdminArea() != null &&
                address.getAdminArea().equalsIgnoreCase("Erbil Governorate") &&
                address.getSubAdminArea().equalsIgnoreCase("Erbil")) {

            PostPropertyPage01Activity.m_PostPropertyAPIData.setGoogleStateName("Kurdistan Region");
        } else {
            PostPropertyPage01Activity.m_PostPropertyAPIData.setGoogleStateName(address.getAdminArea());
        }
        PostPropertyPage01Activity.m_PostPropertyAPIData.setGoogleCountryName(address.getCountryName());
        PostPropertyPage01Activity.m_PostPropertyAPIData.setPropertyLatitude(String.valueOf(latitude));
        PostPropertyPage01Activity.m_PostPropertyAPIData.setPropertyLongitude(String.valueOf(longitude));
        PostPropertyPage01Activity.m_PostPropertyAPIData.setPropertyZipCode(address.getPostalCode());
        PostPropertyPage01Activity.m_PostPropertyAPIData.setGoogleCityName(address.getLocality() != null && !address.getLocality().isEmpty() ? address.getLocality() + ", " + address.getSubAdminArea() : address.getSubAdminArea());
        try {
            PostPropertyPage01Activity.m_PostPropertyAPIData.setPropertyAddress1(address.getAddressLine(0));
        } catch (Exception e) {
            FirebaseCrashlytics.getInstance().recordException(e);
            PostPropertyPage01Activity.m_PostPropertyAPIData.setPropertyAddress1(address.getLocality());
        }
        PostPropertyPage01Activity.m_PostPropertyAPIData.setPropertyAddress2("");
        binding.tvAddress.setText(PostPropertyPage01Activity.m_PostPropertyAPIData.getPropertyAddress1());
        binding.tvCity.setText(address.getLocality() != null && !address.getLocality().isEmpty() ? address.getLocality() + ", " + address.getSubAdminArea() : address.getSubAdminArea());
        binding.tvLatitude.setText(Utils.getDecimalFormat(latitude, Utils.DECIMAL_4));
        binding.tvLongitude.setText(Utils.getDecimalFormat(longitude, Utils.DECIMAL_4));
    }

    @Override
    public void onCameraMoveCanceled() {

    }

    @Override
    public void onCameraMove() {

    }

    public void onBackClick() {
        onBackPressed();
    }


    public void onNextClick() {
        if (PostPropertyPage01Activity.m_PostPropertyAPIData.getGoogleCountryName() != null && !PostPropertyPage01Activity.m_PostPropertyAPIData.getGoogleCountryName().isEmpty()) {
            startActivity(new Intent(PostPropertyPage02Activity.this, PostPropertyPage05Activity.class));

        } else {
            Toast.makeText(this, getString(R.string.no_address_found), Toast.LENGTH_SHORT).show();



        }
    }
}