package com.paya.paragon.activity.intro;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.app.ActivityOptionsCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;

import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings;
import com.paya.paragon.R;
import com.paya.paragon.activity.CitySelectionActivity;
import com.paya.paragon.activity.LanguageActivity;
import com.paya.paragon.PropertyProjectListActivity;
import com.paya.paragon.activity.details.ActivityAgentDetails;
import com.paya.paragon.activity.details.ActivityProjectDetails;
import com.paya.paragon.activity.details.ActivityPropertyDetails;
import com.paya.paragon.activity.localExpert.ActivityLocalExpertDetails;
import com.paya.paragon.commonClass.GlobalValues;
import com.paya.paragon.utilities.AppConstant;
import com.paya.paragon.utilities.SessionManager;
import com.paya.paragon.utilities.Utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;

import pl.droidsonroids.gif.GifImageView;

public class ActivitySplashScreen extends AppCompatActivity {

    private FirebaseRemoteConfig mFirebaseRemoteConfig;
    private String PLAY_STORE_LINK = "https://play.google.com/store/apps/details?id=com.paya.paragon&hl=en";

    private final String PREFIX_PROPERTY = "prd";
    private final String PREFIX_PROJECT = "pjd";
    public String mUrl = "",mType="",mType_Id="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);

        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }
        String langName = SessionManager.getLanguageName(this);
        if (langName != null) {
            toggleLanguage(langName);
        }
        setContentView(R.layout.layout_splash_screen);
        printHashKey(this);
        initializeGifImages();
        initializeFirebaseRemoteConfig();
        checkAppUpdate();
    }



    private void  initializeFirebaseRemoteConfig() {
        mFirebaseRemoteConfig = FirebaseRemoteConfig.getInstance();
        FirebaseRemoteConfigSettings configSettings = new FirebaseRemoteConfigSettings.Builder()
                .setMinimumFetchIntervalInSeconds(0)
                .build();
        mFirebaseRemoteConfig.setConfigSettingsAsync(configSettings);
        mFirebaseRemoteConfig.setDefaultsAsync(R.xml.firebase_remote_config_default);
        mFirebaseRemoteConfig.fetchAndActivate();

    }

    private void checkAppUpdate() {
        String currentAppVersion = getAppVersion();
        String softUpdateVersion = mFirebaseRemoteConfig.getString("soft_update_version_no");
        String forceUpdateVersion = mFirebaseRemoteConfig.getString("force_update_version_no");
        if (!TextUtils.isEmpty(currentAppVersion) && !TextUtils.isEmpty(forceUpdateVersion) && !TextUtils.isEmpty(softUpdateVersion)) {
            if (Integer.parseInt(currentAppVersion.replace(".", "")) < Integer.parseInt(forceUpdateVersion.replace(".", ""))) {
                forceUpdatePopUp();
                return;
            } else if (Integer.parseInt(currentAppVersion.replace(".", "")) < Integer.parseInt(softUpdateVersion.replace(".", ""))) {
                softUpdateUpdatePopUp();
                return;
            } else {
                startActivityAfterDelay();
            }
        } else {
            startActivityAfterDelay();
        }
    }

    private void forceUpdatePopUp() {
        AlertDialog updateApp;
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
        alertDialog.setTitle(getString(R.string.text_app_update_title))
                .setMessage(getString(R.string.text_force_update_message))
                .setCancelable(false);
        alertDialog.setPositiveButton(getString(R.string.text_update), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                SessionManager.logout(ActivitySplashScreen.this);
                openStoreAction();
                dialog.dismiss();
            }
        });
        updateApp = alertDialog.create();
        updateApp.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                updateApp.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(ContextCompat.getColor(ActivitySplashScreen.this, R.color.yellow));
            }
        });
        updateApp.show();
    }

    private void softUpdateUpdatePopUp() {
        AlertDialog updateApp;
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
        alertDialog.setTitle(getString(R.string.text_app_update_title))
                .setMessage(getString(R.string.text_soft_update_message))
                .setCancelable(false);
        alertDialog.setPositiveButton(getString(R.string.text_update), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                SessionManager.logout(ActivitySplashScreen.this);
                openStoreAction();
                dialog.dismiss();
            }
        });

        alertDialog.setNegativeButton(getString(R.string.text_skip), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startActivityAfterDelay();
                dialog.dismiss();
            }
        });
        updateApp = alertDialog.create();
        updateApp.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                updateApp.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(ContextCompat.getColor(ActivitySplashScreen.this, R.color.yellow));
                updateApp.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(ContextCompat.getColor(ActivitySplashScreen.this, R.color.yellow));
            }
        });
        updateApp.show();
    }

    private void openStoreAction() {
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(applicationLink())));
    }

    private String applicationLink() {
        return String.format(PLAY_STORE_LINK, getPackageName());
    }

    private String getAppVersion() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }


    private void startActivityAfterDelay() {
        int TIME_OUT = 2000;
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                getIntentValues();

            }
        }, TIME_OUT);
    }
    private void getIntentValues() {
        if (getIntent() != null)
        {
//            mUrl  = getIntent().getStringExtra("propertyUrl");
            mType  = getIntent().getStringExtra("type");
            mType_Id  = getIntent().getStringExtra("type_id");
        }
        checkIntent();
    }

    private void checkIntent() {

        try {
            String action = getIntent() != null && !TextUtils.isEmpty(getIntent().getAction()) ? getIntent().getAction() : null;
            if (action != null && action.equals("android.intent.action.MAIN")) {

                if(!mType.isEmpty()){
                    Log.d("push","from main "+mType+" "+mType_Id);
                    openRespectiveActivity(mType,mType_Id);
                }else {
                    startHomeActivity();
                }
            } else {
                Log.d("push","from data "+mUrl);

                mUrl = String.valueOf(getIntent().getData());

                openRespectiveActivity(mType,mType_Id);

            }
        } catch (Exception e) {
            FirebaseCrashlytics.getInstance().recordException(e);
            startHomeActivity();
        }
    }

    private void openRespectiveActivity(String type,String typeId) {

        Intent startIntent;
        if(mType!=null && !mType.isEmpty()){
            if(type.equalsIgnoreCase("property")){
                startIntent = new Intent(this, ActivityPropertyDetails.class);
                startIntent.putExtra("propertyID", typeId);
                startIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(startIntent);
                finish();
            }else if(type.equalsIgnoreCase("project")){
                startIntent = new Intent(this, ActivityProjectDetails.class);
                startIntent.putExtra("projectID", typeId);
                startIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(startIntent);
                finish();
            }else if(type.equalsIgnoreCase("agency")){
                startIntent = new Intent(this, ActivityAgentDetails.class);
                startIntent.putExtra(AppConstant.AGENT_ID, typeId);
                startIntent.putExtra(AppConstant.I_SUB_AGENT_FOR_PARENT, true);
                startIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(startIntent);
                finish();
            }else if(type.equalsIgnoreCase("service")){
                startIntent = new Intent(this, ActivityLocalExpertDetails.class);
                startIntent.putExtra("localExpertId", typeId);
                startIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(startIntent);
            }
            else {
                startHomeActivity();
            }
        }else {
            String[] splitUrl = mUrl.split("/");
            if (splitUrl != null && splitUrl.length > 0) {
                if (splitUrl[splitUrl.length - 1].equalsIgnoreCase(PREFIX_PROPERTY)) {
                    startIntent = new Intent(this, ActivityPropertyDetails.class);
                    startIntent.putExtra("propertyID", splitUrl[splitUrl.length - 2]);
                    startIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    startActivity(startIntent);
                    finish();
                } else if (splitUrl[splitUrl.length - 1].equalsIgnoreCase(PREFIX_PROJECT)) {
                    startIntent = new Intent(this, ActivityProjectDetails.class);
                    startIntent.putExtra("projectID", splitUrl[splitUrl.length - 2]);
                    startIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    startActivity(startIntent);
                    finish();
                } else {
                    startHomeActivity();
                }
            } else {
                startHomeActivity();
            }
        }


    }


    private void initializeGifImages() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        GlobalValues.screen_height = displayMetrics.heightPixels;
        GlobalValues.screen_width = displayMetrics.widthPixels;


        GifImageView gifImageView = findViewById(R.id.gif_img);
        AppCompatImageView appCompatImageView = findViewById(R.id.img_logo);
        gifImageView.setVisibility(View.GONE);
        appCompatImageView.setVisibility(View.VISIBLE);
    }


    public void printHashKey(Context pContext) {
        String TAG = "FacebookHashTracer";
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNATURES);
            for (android.content.pm.Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                String hashKey = new String(Base64.encode(md.digest(), 0));
            }
        } catch (NoSuchAlgorithmException e) {
            FirebaseCrashlytics.getInstance().recordException(e);
            Log.e(TAG, "printHashKey()", e);
        } catch (Exception e) {
            FirebaseCrashlytics.getInstance().recordException(e);
            Log.e(TAG, "printHashKey()", e);
        }
    }

    public void toggleLanguage(String langName) {
        Locale locale = new Locale(langName.contains(Utils.LAG_ENGLISH) ? "en" : langName.contains(Utils.LAG_ARABIC) ? "ar" : "ku");
        Locale.setDefault(locale);
        Configuration config = getResources().getConfiguration();
        config.locale = locale;
        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
    }

    public void startHomeActivity() {
        Intent intent;
        if (SessionManager.isFirstTimeLaunch(this)) {
            intent = new Intent(ActivitySplashScreen.this, LanguageActivity.class);
        } else if (SessionManager.getLocationId(this) != null && !SessionManager.getLocationId(this).isEmpty()) {
            GlobalValues.clearBuyGlobalValues();
            intent = new Intent(ActivitySplashScreen.this, PropertyProjectListActivity.class);
            intent.putExtra("searchPropertyPurpose", "Sell");
        } else {
            intent = new Intent(ActivitySplashScreen.this, CitySelectionActivity.class);
        }
        startActivity(intent);
//        finish();
    }


}
