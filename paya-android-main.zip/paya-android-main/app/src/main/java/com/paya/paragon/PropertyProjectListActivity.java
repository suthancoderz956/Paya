package com.paya.paragon;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.databinding.DataBindingUtil;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.paya.paragon.activity.LanguageActivity;
import com.paya.paragon.activity.agent.AgentListFragment;
import com.paya.paragon.activity.buy.IMapMarkerLocation;
import com.paya.paragon.activity.buy.LocationsActivity;
import com.paya.paragon.activity.buy.ProjectListFragment;
import com.paya.paragon.activity.buy.PropertyListFragment;
import com.paya.paragon.activity.dashboard.ActivityMyProperties;
import com.paya.paragon.activity.dashboard.ActivityPostedRequirements;
import com.paya.paragon.activity.dashboard.ActivitySettings;
import com.paya.paragon.activity.dashboard.ActivityShortlisted;
import com.paya.paragon.activity.dashboard.ProfileActivity;
import com.paya.paragon.activity.localExpert.ActivityLocalExpertDashboard;
import com.paya.paragon.activity.login.ActivityLoginEmail;
import com.paya.paragon.activity.login.ActivityOTP;
import com.paya.paragon.activity.postProperty.PostPropertyLocationSelection;
import com.paya.paragon.activity.postProperty.PostPropertyPage01Activity;
import com.paya.paragon.activity.postRequirements.ActivityRequirementPurpose;
import com.paya.paragon.activity.search.ActivityFilter;
import com.paya.paragon.api.BuyAgents.BuyAgentsListApi;
import com.paya.paragon.api.BuyAgents.BuyAgentsListData;
import com.paya.paragon.api.BuyAgents.BuyAgentsListResponse;
import com.paya.paragon.api.BuyAgents.BuyAgentsModel;
import com.paya.paragon.api.BuyProjects.BuyProjectsListApi;
import com.paya.paragon.api.BuyProjects.BuyProjectsListData;
import com.paya.paragon.api.BuyProjects.BuyProjectsListResponse;
import com.paya.paragon.api.BuyProjects.BuyProjectsModel;
import com.paya.paragon.api.BuyProperties.BuyPropertiesListApi;
import com.paya.paragon.api.BuyProperties.BuyPropertiesListData;
import com.paya.paragon.api.BuyProperties.BuyPropertiesListResponse;
import com.paya.paragon.api.BuyProperties.BuyPropertiesModel;
import com.paya.paragon.api.PayaAPICall;
import com.paya.paragon.api.postProperty.attributeListing.AllAttributesData;
import com.paya.paragon.commonClass.ApiLinks;
import com.paya.paragon.commonClass.GlobalValues;
import com.paya.paragon.databinding.PropertyProjectListActivityBinding;
import com.paya.paragon.utilities.AppConstant;
import com.paya.paragon.utilities.DialogProgress;
import com.paya.paragon.utilities.ListDialogBox;
import com.paya.paragon.utilities.PropertyProjectType;
import com.paya.paragon.utilities.SessionManager;
import com.paya.paragon.utilities.ShortListListener;
import com.paya.paragon.utilities.Utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


@SuppressWarnings({"ConstantConditions", "HardCodedStringLiteral", "RedundantCast", "NullableProblems"})
public class  PropertyProjectListActivity extends AppCompatActivity implements View.OnClickListener, ShortListListener,
        IMapMarkerLocation, TextWatcher {
    TextView mTitle;
    TextView tvLanguage;
    ImageView imgFlag;
    TextView tvProfileName;
    LinearLayout llProfileView;

    String imageURLProperties, imageBaseURLCompany, imageURLProjects, imageURLAgents;
    String strCountAgent, strProjectPropertyCount;
    public static List<BuyPropertiesModel> propertyLists;
    public static List<BuyPropertiesModel> propertyLists_new = new ArrayList<>();

    public static List<BuyProjectsModel> projectLists;
    List<BuyAgentsModel> agentLists;
    ArrayList<AllAttributesData> allAttributesList = new ArrayList<>();

    String searchPropertyPurpose, userId, location_id = "2";
    public static int FILTER = 100;
    public static int selectedPosition = 100;
    List<String> sortText;
    List<String> sortValue;
    private DialogProgress mLoadingDialog;
    public static String siteUrl = "";
    public DrawerLayout drawer;
    private RelativeLayout bottom_heart;
    private LinearLayout add_property, bottom_home;
    public TextView text_city_list, shortListedCount;
    private int shortListedTotal;
    NavigationView navigationView;
    LinearLayout navLogin, navLanguage, navLogout, navCalculator, navDashboard;
    LinearLayout navSellPostAdd, navPostRequirement, navPostedRequirement,
            navSettings, navBuy, navRent, navSavedSearch, navExpertCommunity,
            navMyProperty,navShortlisted;
    private boolean isNewProject = false;
    private PropertyProjectType type;


    //PalanivelraghulWork
    private LinearLayout llProperty;
    private LinearLayout llProject;
    private LinearLayout llAgent;
    private LinearLayout llMenu;
    private LinearLayout llContactPaya;
    private ImageView imgProperty;
    private ImageView imgProject;
    private ImageView imgAgent;
    private ImageView imgHamburgerMenu;
    private TextView tvNavProperty;
    private TextView tvNavProject;
    private TextView tvNavAgents;
    private TextView tvNavMenu;
    private TableRow trTopFilterSortAndMap;
    private TextView tvFilterSearch;
    private ImageView imgSort;
    private ImageView imgMap;
    private boolean isExit;
    private boolean isPropertyTabSelected = false;
    private boolean isProjectTabSelected = false;

    private AppBarLayout appbar;

    private PropertyProjectListActivityBinding binding;
    private PropertyProjectListActivityCallBack projectListActivityCallBack;



    public void setAgentFragmentCallBack(PropertyProjectListActivityCallBack projectListActivityCallBack) {
        this.projectListActivityCallBack = projectListActivityCallBack;
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.property_project_list_activity);
        initiateToolbar();
        initiateViews();
        initiateData();
        appVersion();

        Log.d("token",SessionManager.getDeviceTokenForFCM(this));
    }

    private void initiateToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        mTitle = toolbar.findViewById(R.id.toolbar_title);
        mTitle.setTextSize(18);
        getSupportActionBar().setElevation(0);
    }

    private void appVersion() {
        TextView appVersion = findViewById(R.id.tv_app_version);
        appVersion.setText(Utils.getPackageVersionName(this));
    }

    private void initiateViews() {

        trTopFilterSortAndMap = findViewById(R.id.tr_filter_sort_map);
        tvFilterSearch = findViewById(R.id.text_filter_search);
        imgSort = findViewById(R.id.img_sort);
        imgMap = findViewById(R.id.img_map);

        drawer = (DrawerLayout) findViewById(R.id.drawer_layout_home);
        tvLanguage = findViewById(R.id.tv_language);
        imgFlag = findViewById(R.id.img_flag);
        llProfileView = findViewById(R.id.ll_profile_view);
        tvProfileName = findViewById(R.id.tv_profile_name);
        navigationView = (NavigationView) findViewById(R.id.nav_view_home);
        navLogin = navigationView.findViewById(R.id.nav_item_login);
        navLanguage = navigationView.findViewById(R.id.nav_item_language);
        navLogout = navigationView.findViewById(R.id.nav_item_logout);
        navCalculator = navigationView.findViewById(R.id.nav_item_savings_calculator);
        navDashboard = navigationView.findViewById(R.id.nav_item_dashboard);
        navSellPostAdd = navigationView.findViewById(R.id.nav_item_list_property);
        navPostRequirement = navigationView.findViewById(R.id.nav_item_post_requirements);
        navPostedRequirement = navigationView.findViewById(R.id.nav_item_posted_requirements);
        navSettings = navigationView.findViewById(R.id.nav_item_settings);
        navBuy = navigationView.findViewById(R.id.nav_item_buy);
        navRent = navigationView.findViewById(R.id.nav_item_rent);
        navSavedSearch = navigationView.findViewById(R.id.nav_item_saved_searches);
        navExpertCommunity = navigationView.findViewById(R.id.nav_item_expert_community);
        navMyProperty = navigationView.findViewById(R.id.nav_item_my_properties);
        add_property = findViewById(R.id.add_property);
        bottom_heart = findViewById(R.id.bottom_heart);
        bottom_home = findViewById(R.id.bottom_home);
        shortListedCount = findViewById(R.id.shortListedCount);
        //initiateBottomViews
        imgProperty = findViewById(R.id.img_property);
        imgProject = findViewById(R.id.img_project);
        imgAgent = findViewById(R.id.img_nav_agent);
        imgHamburgerMenu = findViewById(R.id.img_hamberger_menu);
        llProperty = findViewById(R.id.ll_property);
        llProject = findViewById(R.id.ll_project);
        llAgent = findViewById(R.id.ll_agents);
        llMenu = findViewById(R.id.ll_menu);
        tvNavProperty = findViewById(R.id.tv_nav_property);
        tvNavProject = findViewById(R.id.tv_nav_project);
        tvNavAgents = findViewById(R.id.tv_nav_agent);
        llContactPaya = findViewById(R.id.ll_contact_paya);
        tvNavMenu = findViewById(R.id.tv_nav_menu);

        navShortlisted = findViewById(R.id.nav_item_favourites);
        appbar = (AppBarLayout) findViewById(R.id.app_bar_layout);

        navCalculator.setOnClickListener(this);
        navDashboard.setOnClickListener(this);
        navPostRequirement.setOnClickListener(this);
        navPostedRequirement.setOnClickListener(this);
        navSettings.setOnClickListener(this);
        navSellPostAdd.setOnClickListener(this);
        navSavedSearch.setOnClickListener(this);
        navMyProperty.setOnClickListener(this);
        navExpertCommunity.setOnClickListener(this);
        navBuy.setOnClickListener(this);
        navRent.setOnClickListener(this);
        navLogin.setOnClickListener(this);
        navLanguage.setOnClickListener(this);
        llProfileView.setOnClickListener(this);
        llContactPaya.setOnClickListener(this);
        navLogout.setOnClickListener(this);
        add_property.setOnClickListener(this);
        bottom_heart.setOnClickListener(this);
        bottom_home.setOnClickListener(this);
        imgProperty.setOnClickListener(this);
        imgProject.setOnClickListener(this);
        imgHamburgerMenu.setOnClickListener(this);
        imgAgent.setOnClickListener(this);
        llProperty.setOnClickListener(this);
        llProject.setOnClickListener(this);
        llAgent.setOnClickListener(this);
        llMenu.setOnClickListener(this);

        navShortlisted.setOnClickListener(this);

        tvFilterSearch.setOnClickListener(this);
        imgMap.setOnClickListener(this);
        imgSort.setOnClickListener(this);

        binding.llMainLayout.imgAgentSort.setOnClickListener(this);
        binding.llMainLayout.imgAgentSearchClear.setOnClickListener(this);
        binding.llMainLayout.imgAgentSearch.setOnClickListener(this);
    }

    private void initiateData() {
        mLoadingDialog = new DialogProgress(PropertyProjectListActivity.this);
        mLoadingDialog.show();
        searchPropertyPurpose = getIntent().getStringExtra("searchPropertyPurpose");
        isNewProject = getIntent().getBooleanExtra("newProject", false);
        type = isNewProject ? PropertyProjectType.NEW_PROJECT : PropertyProjectType.BUY;
        GlobalValues.searchPropertyPurpose = searchPropertyPurpose;
        if (isNewProject) {
            GlobalValues.selectedSortValue = "date/orderby/desc";
            GlobalValues.selectedSortText = getString(R.string.new_listing);
        }
        if (searchPropertyPurpose.equalsIgnoreCase("Sell")) {
            type = isNewProject ? PropertyProjectType.NEW_PROJECT : PropertyProjectType.BUY;
        } else {
            type = isNewProject ? PropertyProjectType.NEW_PROJECT : PropertyProjectType.RENT;
        }
        setToolbarTitle(getString(R.string.properties));
        if (SessionManager.getLoginStatus(PropertyProjectListActivity.this)) {
            userId = SessionManager.getAccessToken(PropertyProjectListActivity.this);
        } else {
            userId = "";
        }

        setDefaultSortValuesForProjectAndProperty();
        tvLanguage.setText(SessionManager.getLanguageName(this));
        imgFlag.setImageDrawable(Utils.getLanguageFlag(SessionManager.getLanguageName(this)));
        location_id = SessionManager.getLocationId(this);

        onPropertyTabSelection();
    }

    private void setDefaultSortValuesForProjectAndProperty() {
        sortText = Arrays.asList(getResources().getStringArray(R.array.sortList));
        sortValue = Arrays.asList(getResources().getStringArray(R.array.sortValue));
        if (GlobalValues.selectedSortText == null) {
            GlobalValues.selectedSortText = sortText.get(3);
            GlobalValues.selectedSortValue = sortValue.get(3);
        }
    }

    private String setToolbarTitle(String type) {
        String title = "";
        int id = Utils.getCitNameBasedOnLanguage(SessionManager.getLocationId(this));
        String propertyType = getString(searchPropertyPurpose.equalsIgnoreCase("Sell") ? R.string.sale : R.string.rent);
        title = String.format("%s %s %s %s",getString(type.equalsIgnoreCase(getString(R.string.properties)) ? R.string.properties_for : R.string.projects_for),
                type.equalsIgnoreCase(getString(R.string.properties)) ? propertyType : "",
                getString(R.string.in),
                id != 0 ? getString(id) : "");
        mTitle.setText(title);
        return title;
    }

    public Dialog alertDialog;

    private void alertLogout() {
        alertDialog = new Dialog(this);
        alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LayoutInflater factory = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        assert factory != null;
        @SuppressLint("InflateParams") final View alert_layout = factory.inflate(R.layout.alert_exit_popup, null);
        TextView ok = alert_layout.findViewById(R.id.alert_ok_button);
        TextView cancel = alert_layout.findViewById(R.id.alert_cancel_button);

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                alertDialog.dismiss();
            }
        });

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
                SessionManager.logout(PropertyProjectListActivity.this);
                navLogin.setVisibility(View.VISIBLE);
                navLogout.setVisibility(View.GONE);
                navLogin.requestFocus();
                llProfileView.setVisibility(View.GONE);
                checkLogin();
            }
        });

        alertDialog.setContentView(alert_layout);
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        alertDialog.setCanceledOnTouchOutside(true);
        alertDialog.show();
    }

    public void checkLogin() {
        boolean isLoggedInUser = SessionManager.getLoginStatus(PropertyProjectListActivity.this);
        navLogin.setVisibility(isLoggedInUser ? View.GONE : View.VISIBLE);
        navLogout.setVisibility(isLoggedInUser ? View.VISIBLE : View.GONE);
        llProfileView.setVisibility(isLoggedInUser ? View.VISIBLE : View.GONE);
        navSettings.setVisibility(isLoggedInUser ? View.VISIBLE : View.GONE);
        navPostedRequirement.setVisibility(isLoggedInUser ? View.VISIBLE : View.GONE);
        navShortlisted.setVisibility(isLoggedInUser ? View.VISIBLE : View.GONE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILTER) {
            if (resultCode == Activity.RESULT_OK) {
                searchPropertyPurpose = data.getStringExtra("selectedType");
                GlobalValues.searchPropertyPurpose = searchPropertyPurpose;
                type = (PropertyProjectType) data.getSerializableExtra(Utils.TYPE);
                allAttributesList = (ArrayList<AllAttributesData>) data.getSerializableExtra("attributes");
                if (searchPropertyPurpose.equals("Sell")) {
                    mTitle.setText(R.string.buy);
                } else {
                    mTitle.setText(searchPropertyPurpose);
                }
                //count = 0;
                if (!SessionManager.getLocationId(this).equals("-1"))
                    location_id = SessionManager.getLocationId(this);
                resultBasedOnPreviousTabSelection();
            }

        } else if (12345 == requestCode) {
            /*if (resultCode == Activity.RESULT_OK) {
                Log.e("onActivityResult: ###########", "********" + data.getStringArrayListExtra(AppConstant.I_SELECTED_IMAGE_PATH));
            }*/
        }
    }

    private void resultBasedOnPreviousTabSelection() {
        if (isProjectTabSelected) {
            onProjectTabSelection();
        } else if (isPropertyTabSelected) {
            onPropertyTabSelection();
        }
    }

    @Override
    public void increaseClick() {
        shortListedTotal = shortListedTotal + 1;
        shortListedCount.setText(String.valueOf(shortListedTotal));

        if (shortListedTotal > 0)
            shortListedCount.setBackground(getDrawable(R.drawable.cart_round));
        else shortListedCount.setBackground(getDrawable(R.drawable.cart_round_disable));
    }

    @Override
    public void decreaseClick() {
        shortListedTotal = shortListedTotal - 1;
        shortListedCount.setText(String.valueOf(shortListedTotal));

        if (shortListedTotal > 0)
            shortListedCount.setBackground(getDrawable(R.drawable.cart_round));
        else shortListedCount.setBackground(getDrawable(R.drawable.cart_round_disable));
    }


    //TODO API Calls
    //get properties
    public void apiGetProperties() {
        mLoadingDialog.show();




        ApiLinks.getClient().create(BuyPropertiesListApi.class).post(
                userId,
                SessionManager.getLanguageID(this),
                location_id,
                searchPropertyPurpose,
                "0",
                "Property",
                "" + GlobalValues.selectedSortValue,
                GlobalValues.selectedMinPrice == null ? "0" : GlobalValues.selectedMinPrice,
                GlobalValues.selectedMaxPrice == null ? "0" : GlobalValues.selectedMaxPrice,
                GlobalValues.selectedPropertyTypeID == null ? "" : GlobalValues.selectedPropertyTypeID,
                GlobalValues.countryID,
                GlobalValues.selectedBedroomsNumber,
                GlobalValues.selectedFurnishedStaticValue,
                GlobalValues.selectedRegionId,
                GlobalValues.possessionStatus,
                "",
                "",
                "",
                "")
                .enqueue(new Callback<BuyPropertiesListResponse>() {
                    @Override
                    public void onResponse(Call<BuyPropertiesListResponse> call,
                                           Response<BuyPropertiesListResponse> response) {
                        if (response.isSuccessful()) {
                            if (response.body().getResponse().equalsIgnoreCase("Success")) {
                                BuyPropertiesListData data = response.body().getData();
                                imageURLProperties = data.getImageURL();
                                imageBaseURLCompany = data.getCompanyProfileLogoUrl();
                                siteUrl = data.getSiteUrl();
                                strProjectPropertyCount = data.getSearchPropertyCount();
                                propertyLists = data.getPropertyLists();
                                setPropertyListForMap(data.getPropertyLists());
                            } else {
                                dismissAnimationLoading();
                                strProjectPropertyCount = "0";
                                propertyLists = null;
                            }
                            initiatePropertyListData();
                        } else {
                            dismissAnimationLoading();
                            Log.e("Status", "Failed");
                        }

                    }

                    @Override
                    public void onFailure(Call<BuyPropertiesListResponse> call, Throwable t) {
                        Log.e("apiGetProperties", t.getMessage());
                        dismissAnimationLoading();
                    }
                });
    }

    //get projects
    public void apiGetProjects() {
        mLoadingDialog.show();
        ApiLinks.getClient().create(BuyProjectsListApi.class).post(userId,
                SessionManager.getLanguageID(this),
                location_id,
                searchPropertyPurpose,
                "0",
                "Project",
                GlobalValues.selectedSortValue,
                GlobalValues.selectedMinPrice == null ? "0" : GlobalValues.selectedMinPrice,
                GlobalValues.selectedMaxPrice == null ? "0" : GlobalValues.selectedMaxPrice,
                GlobalValues.selectedPropertyTypeID == null ? "" : GlobalValues.selectedPropertyTypeID,
                GlobalValues.countryID,
                GlobalValues.selectedBedroomsNumber,
                GlobalValues.selectedFurnishedStaticValue,
                GlobalValues.selectedRegionId,
                GlobalValues.possessionStatus,
                "",
                "",
                "",
                "")
                .enqueue(new Callback<BuyProjectsListResponse>() {
                    @Override
                    public void onResponse(Call<BuyProjectsListResponse> call,
                                           Response<BuyProjectsListResponse> response) {
                        if (response.isSuccessful()) {
                            if (response.body().getResponse().equals("Success")) {
                                BuyProjectsListData data = response.body().getData();
                                imageURLProjects = data.getImageURL();
                                siteUrl = data.getSiteUrl();
                                strProjectPropertyCount = data.getSearchProjectCount();
                                projectLists = data.getProjectLists();
                            } else {
                                dismissAnimationLoading();
                                strProjectPropertyCount = "0";
                                projectLists = null;
                            }
                            initiateProjectListData();
//                            setTabs(selectedTabPosition);
                        } else {
                            Log.e("Status", "Failed");
                            dismissAnimationLoading();
                        }

                    }

                    @Override
                    public void onFailure(Call<BuyProjectsListResponse> call, Throwable t) {
                        dismissAnimationLoading();
                    }
                });
    }

    //get Agents
    public void apiGetAgents() {
        ApiLinks.getClient().create(BuyAgentsListApi.class).post(
                "" + userId,
                "" + SessionManager.getLanguageID(this),
                "" + location_id,
                "" + searchPropertyPurpose,
                "0",
                "Agent",
                "" + GlobalValues.selectedSortValue,
                "" + GlobalValues.selectedMinPrice,
                "" + GlobalValues.selectedMaxPrice,
                "" + GlobalValues.selectedPropertyTypeID,
                GlobalValues.countryID,
                "" + GlobalValues.selectedBedroomsNumber,
                "" + GlobalValues.selectedRegionId,
                "" + GlobalValues.possessionStatus,
                "",
                "",
                "",
                "").enqueue(new Callback<BuyAgentsListResponse>() {
            @Override
            public void onResponse(Call<BuyAgentsListResponse> call, Response<BuyAgentsListResponse> response) {
                if (response.isSuccessful()) {
                    //count++;
                    if (response.body().getResponse().equals("Success")) {
                        BuyAgentsListData data = response.body().getData();
                        imageURLAgents = data.getImageURL();
                        strCountAgent = data.getSearchAgentCount();
                        agentLists = data.getAgentLists();
                    } else {
                        strCountAgent = "0";
                        agentLists = null;
                    }
                    /*if (count == 2) {
                        setTabs(selectedTabPosition);
                    }*/
                } else {
                    Log.e("Status", "Failed");
                }
            }

            @Override
            public void onFailure(Call<BuyAgentsListResponse> call, Throwable t) {
                dismissAnimationLoading();
            }
        });
    }


    //TODO Main functions
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Utils.changeLayoutOrientationDynamically(this, findViewById(R.id.drawer_layout_home));
        setProfileDetails();
        checkLogin();
    }

    //TODO Click Listener
    public void onClick(View view) {
        if (view == navLogin) {
            drawer.closeDrawer(GravityCompat.END);
            if (SessionManager.getLoginStatus(PropertyProjectListActivity.this)) {
                Intent intentLogin = new Intent(PropertyProjectListActivity.this, ActivityMyProperties.class);
                startActivity(intentLogin);
            } else {
                if(!SessionManager.getPhone(this).isEmpty()){
                    if(!SessionManager.isOTPVerified(this)){
                        startActivity(new Intent(PropertyProjectListActivity.this, ActivityOTP.class).putExtra("comingFrom","signin"));
                    }
                    else {
                        startActivity(new Intent(PropertyProjectListActivity.this, ActivityLoginEmail.class).putExtra("comingFrom", "menu"));
                    }

                }else {
                    startActivity(new Intent(PropertyProjectListActivity.this, ActivityLoginEmail.class).putExtra("comingFrom", "menu"));

                }
            }
        } else if (view == navLanguage) {
            drawer.closeDrawer(GravityCompat.END);
            Intent intent = new Intent(PropertyProjectListActivity.this, LanguageActivity.class);
            startActivity(intent);
        } else if (view == llContactPaya) {
            drawer.closeDrawer(GravityCompat.END);
            Intent callIntent = new Intent(Intent.ACTION_VIEW);
            callIntent.setData(Uri.parse("tel:+9647501297777"));
            startActivity(callIntent);
        } else if (view == llProfileView) {
            drawer.closeDrawer(GravityCompat.END);
            Intent intent = new Intent(PropertyProjectListActivity.this, ProfileActivity.class);
            startActivity(intent);
        } else if (view == navMyProperty) {
            drawer.closeDrawer(GravityCompat.END);
            if (SessionManager.getLoginStatus(PropertyProjectListActivity.this)) {
                startActivity(new Intent(PropertyProjectListActivity.this, ActivityMyProperties.class));
            } else {
                startActivity(new Intent(PropertyProjectListActivity.this, ActivityLoginEmail.class).putExtra("comingFrom", AppConstant.FROM_MY_PROPERTY));
            }
        } else if (view == navSellPostAdd) {
            drawer.closeDrawer(GravityCompat.END);
            if (SessionManager.getLoginStatus(PropertyProjectListActivity.this)) {
                Utils.selectedNeighbourhoodValueMap.clear();
                startActivity(new Intent(PropertyProjectListActivity.this, PostPropertyPage01Activity.class));
            } else {
                startActivity(new Intent(PropertyProjectListActivity.this, ActivityLoginEmail.class).putExtra("comingFrom", AppConstant.FROM_POST_PROPERTY));
            }
        } else if (view == navPostRequirement) {
            drawer.closeDrawer(GravityCompat.END);
            Intent intentPostReq = new Intent(PropertyProjectListActivity.this, ActivityRequirementPurpose.class);
            startActivity(intentPostReq);
        } else if (view == navPostedRequirement) {
            drawer.closeDrawer(GravityCompat.END);
            Intent intent = new Intent(PropertyProjectListActivity.this, ActivityPostedRequirements.class);
            startActivity(intent);
        } else if (view == navExpertCommunity) {
            drawer.closeDrawer(GravityCompat.END);
            startActivity(new Intent(PropertyProjectListActivity.this, ActivityLocalExpertDashboard.class));
        } else if (view == navSettings) {
            drawer.closeDrawer(GravityCompat.END);
            Intent intent = new Intent(PropertyProjectListActivity.this, ActivitySettings.class);
            startActivity(intent);
        } else if (view == navLogout) {
            drawer.closeDrawer(GravityCompat.END);
            alertLogout();
        } else if(view == navShortlisted){
            Intent intent = new Intent(PropertyProjectListActivity.this, ActivityShortlisted.class);
            startActivity(intent);
        }
        else if (view == llMenu || view == imgHamburgerMenu) {
            if (drawer.isDrawerOpen(GravityCompat.END)) {
                drawer.closeDrawer(GravityCompat.END);
            } else {
                drawer.openDrawer(GravityCompat.END);
            }
        } else if (view == llProperty || view == imgProperty) {
            if (!isSimilarFragment(new PropertyListFragment())) {
                onPropertyTabSelection();
            }
        } else if (view == llProject || view == imgProject) {
            if (!isSimilarFragment(new ProjectListFragment())) {
                onProjectTabSelection();
            }
        } else if (view == llAgent || view == imgAgent) {
            if (!isSimilarFragment(new AgentListFragment())) {
                onAgentTabSelection();
            }
        } else if (imgMap == view) {
            drawer.closeDrawer(GravityCompat.END);
            openPropertyProjectMap();
        } else if (imgSort == view) {
            drawer.closeDrawer(GravityCompat.END);
            openPropertyProjectSortOptionDialog();
        } else if (tvFilterSearch == view) {
            drawer.closeDrawer(GravityCompat.END);
            openFilterActivity();
        } else if (binding.llMainLayout.imgAgentSearch == view) {
            drawer.closeDrawer(GravityCompat.END);
            if (projectListActivityCallBack != null)
                projectListActivityCallBack.agentSearchUsingEnterText();
        } else if (binding.llMainLayout.imgAgentSort == view) {
            drawer.closeDrawer(GravityCompat.END);
            GlobalValues.selectedAgentSortByCount = AppConstant.SORT_BY_DESC.equalsIgnoreCase(GlobalValues.selectedAgentSortByCount) ? AppConstant.SORT_BY_ASC : AppConstant.SORT_BY_DESC;
            binding.llMainLayout.imgAgentSort.setImageDrawable(ContextCompat.getDrawable(this, AppConstant.SORT_BY_DESC.equalsIgnoreCase(GlobalValues.selectedAgentSortByCount) ? R.drawable.ic_arrow_down : R.drawable.ic_arrow_up));
            if (projectListActivityCallBack != null)
                projectListActivityCallBack.agentSortAgentList();
        } else if (binding.llMainLayout.imgAgentSearchClear == view) {
            drawer.closeDrawer(GravityCompat.END);
            if (projectListActivityCallBack != null)
                projectListActivityCallBack.agentClearSearchText();
        }
    }

    private void setProfileDetails() {
        tvProfileName.setText(SessionManager.getFullName(this));
    }


    private void onPropertyTabSelection() {
        checkLocationUpdateForNotification();
        isPropertyTabSelected = true;
        isProjectTabSelected = false;
        isExit = false;
        resetAppBarBehaviour();
        setOptionColorChange(true, false, false, false);
        trTopFilterSortAndMap.setVisibility(View.VISIBLE);
        binding.llMainLayout.llAgentHeader.setVisibility(View.GONE);
        apiGetProperties();
    }

    private void onProjectTabSelection() {
        checkLocationUpdateForNotification();
        isPropertyTabSelected = false;
        isProjectTabSelected = true;
        isExit = false;
        resetAppBarBehaviour();
        setOptionColorChange(false, true, false, false);
        trTopFilterSortAndMap.setVisibility(View.VISIBLE);
        binding.llMainLayout.llAgentHeader.setVisibility(View.GONE);
        apiGetProjects();
    }

    private void onAgentTabSelection() {
        isPropertyTabSelected = false;
        isProjectTabSelected = false;
        isExit = false;
        setOptionColorChange(false, false, true, false);
        mTitle.setText(getString(R.string.agents));
        resetAppBarBehaviour();
        trTopFilterSortAndMap.setVisibility(View.GONE);
        binding.llMainLayout.llAgentHeader.setVisibility(View.VISIBLE);
        binding.llMainLayout.edtFilterSearch.addTextChangedListener(this);
        loadFragment(new AgentListFragment());
    }

    private void setOptionColorChange(boolean isPropertySelected, boolean isProjectSelected, boolean isAgentSelected, boolean isMenuSelected) {
        tvNavProperty.setTextColor(ContextCompat.getColor(this, isPropertySelected ? R.color.black : R.color.quantum_grey));
        imgProperty.setImageDrawable(ContextCompat.getDrawable(this, isPropertySelected ? R.drawable.ic_nav_property : R.drawable.ic_nav_deselect_properties));
        tvNavProperty.setTypeface(null, isPropertySelected ? Typeface.BOLD : Typeface.NORMAL);
        tvNavProject.setTextColor(ContextCompat.getColor(this, isProjectSelected ? R.color.black : R.color.quantum_grey));
        tvNavProject.setTypeface(null, isProjectSelected ? Typeface.BOLD : Typeface.NORMAL);
        imgProject.setImageDrawable(ContextCompat.getDrawable(this, isProjectSelected ? R.drawable.ic_nav_projects : R.drawable.ic_nav_deselect_project));
        tvNavAgents.setTextColor(ContextCompat.getColor(this, isAgentSelected ? R.color.black : R.color.quantum_grey));
        tvNavAgents.setTypeface(null, isAgentSelected ? Typeface.BOLD : Typeface.NORMAL);
        imgAgent.setImageDrawable(ContextCompat.getDrawable(this, isAgentSelected ? R.drawable.ic_nav_agents : R.drawable.ic_nav_deselect_agent));
        tvNavMenu.setTextColor(ContextCompat.getColor(this, isMenuSelected ? R.color.black : R.color.quantum_grey));
        tvNavMenu.setTypeface(null, isMenuSelected ? Typeface.BOLD : Typeface.NORMAL);
        imgHamburgerMenu.setImageDrawable(ContextCompat.getDrawable(this, isMenuSelected ? R.drawable.ic_nav_menu : R.drawable.ic_nav_deselect_menu));
    }

    private void initiatePropertyListData() {
        PropertyListFragment fragment = new PropertyListFragment(propertyLists, imageURLProperties, imageBaseURLCompany, strProjectPropertyCount, searchPropertyPurpose, type);
        if (propertyLists != null && !propertyLists.isEmpty()) {
            mTitle.setText(String.format("(%s) %s", strProjectPropertyCount, setToolbarTitle(getString(R.string.properties))));
        } else {
            setToolbarTitle(getString(R.string.properties));
        }
        fragment.setListener(this);
        loadFragment(fragment);
        imgMap.setVisibility((propertyLists == null || propertyLists.size() == 0) ? View.GONE : View.VISIBLE);
        dismissAnimationLoading();
    }

    private void initiateProjectListData() {
        ProjectListFragment fragment = new ProjectListFragment(projectLists, imageURLProjects, strProjectPropertyCount, searchPropertyPurpose, type);
        if (projectLists != null && !projectLists.isEmpty()) {
            mTitle.setText(String.format("(%s) %s", strProjectPropertyCount, setToolbarTitle(getString(R.string.projects))));
        } else {
            setToolbarTitle(getString(R.string.projects));
        }
        fragment.setListener(this);
        loadFragment(fragment);
        imgMap.setVisibility((projectLists == null || projectLists.size() == 0) ? View.GONE : View.VISIBLE);
        dismissAnimationLoading();
    }

    private void resetAppBarBehaviour() {
        if (appbar != null)
            appbar.setExpanded(true, false);
    }

    /**
     * call this method to update data for city based notification is not updated when city selection is happened
     * in CityLocationSelection activity and filter activity.
     */
    private void checkLocationUpdateForNotification() {
        if (!SessionManager.isCityUpdateNotificationUpdated(this)) {
            new PayaAPICall().initiateUpdateCityForUserNotification(this);
        }
    }

    private void dismissAnimationLoading() {
        if (mLoadingDialog != null && mLoadingDialog.isShowing()) {
            mLoadingDialog.dismiss();
        }
    }

    private void loadFragment(Fragment fragment) {
        new Handler().post(new Runnable() {
            public void run() {
                try {
                    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.fl_container, fragment, fragment.getClass().getName());
                    fragmentTransaction.addToBackStack(fragment.getClass().getName());
                    fragmentTransaction.commitAllowingStateLoss();
                } catch (Exception e) {
                    FirebaseCrashlytics.getInstance().recordException(e);
                    finish();
                }
            }
        });
    }

    private boolean isSimilarFragment(Fragment fragment) {
        return fragment != null && getActiveFragment() != null && fragment.getClass().getName().equals(getActiveFragment().getClass().getName());
    }

    private Fragment getActiveFragment() {
        if (getSupportFragmentManager().getBackStackEntryCount() == 0) {
            return null;
        }
        return getSupportFragmentManager().findFragmentByTag(getSupportFragmentManager().getBackStackEntryAt(getSupportFragmentManager().getBackStackEntryCount() - 1).getName());
    }


    @Override
    public void setPropertyListForMap(List<BuyPropertiesModel> propertyLists) {
        propertyLists_new = new ArrayList<>();
        if (propertyLists_new.size() == 0) {
            propertyLists_new.addAll(propertyLists);
        } else {
            propertyLists_new.addAll(propertyLists_new.size() - 1, propertyLists);
        }
    }

    @Override
    public void setProjectListForMap(List<BuyProjectsModel> projectLists) {

    }

    private void openPropertyProjectSortOptionDialog() {
        selectedPosition = 100;
        ListDialogBox dialogBox = new ListDialogBox(PropertyProjectListActivity.this, sortText, getString(R.string.sort_by), "sort");
        dialogBox.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialogBox.show();
        dialogBox.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                if (selectedPosition != 100) {
                    GlobalValues.selectedSortValue = sortValue.get(selectedPosition);
                    GlobalValues.selectedSortText = sortText.get(selectedPosition);
                    resultBasedOnPreviousTabSelection();
                }
            }
        });
    }

    private void openFilterActivity() {
        Intent intentBuy = new Intent(PropertyProjectListActivity.this, ActivityFilter.class);
        intentBuy.putExtra("attributes", allAttributesList);
        intentBuy.putExtra("Properties_Tab_Selected",isPropertyTabSelected);
        startActivityForResult(intentBuy, FILTER);
    }

    private void openPropertyProjectMap() {
        Intent in = new Intent(PropertyProjectListActivity.this, LocationsActivity.class);
        if (isPropertyTabSelected) {
          /*  Bundle args = new Bundle();
            args.putSerializable("property_list_array", (Serializable) propertyLists_new);
            in.putExtra("bundle_property", args);*/
            in.putExtra("from", "Properties");
        } else if (isProjectTabSelected) {
            in.putExtra("from", "Projects");
        }
        in.putExtra(AppConstant.I_SEARCH_PURPOSE, searchPropertyPurpose);
        in.putExtra(AppConstant.I_USER_ID, userId);
        in.putExtra(Utils.TYPE, type);
        startActivity(in);
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.END)) {
            drawer.closeDrawer(GravityCompat.END);
        } else if (getActiveFragment() != null) {
            if (PropertyListFragment.class.getName().equals(getActiveFragment().getClass().getName())) {
                if (!isExit) {
                    isExit = true;
                    Toast.makeText(this, "Press once again to exit", Toast.LENGTH_SHORT).show();
                } else {
                    finish();
                }
            } else {
                getSupportFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                onPropertyTabSelection();
            }
        } else {
            finish();
        }
    }

    @Override
    protected void onDestroy() {
        dismissAnimationLoading();
        super.onDestroy();
    }

    public void updateTotalAgentCount(int totalAgentDataCount) {
        binding.llMainLayout.imgAgentSort.setVisibility(totalAgentDataCount > 0 ? View.VISIBLE : View.GONE);
        if (totalAgentDataCount > 0) {
            mTitle.setText(String.format("%s (%s)", getString(R.string.agents), totalAgentDataCount));
        } else {
            mTitle.setText(getString(R.string.agents));
        }
    }

    public void updateSearchIcons(boolean isSearchTextPresent) {
        if (!isSearchTextPresent) {
            binding.llMainLayout.edtFilterSearch.removeTextChangedListener(this);
            binding.llMainLayout.edtFilterSearch.setText("");
            binding.llMainLayout.edtFilterSearch.addTextChangedListener(this);
        }
        binding.llMainLayout.imgAgentSearchClear.setVisibility(isSearchTextPresent ? View.VISIBLE : View.GONE);
    }

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        if (projectListActivityCallBack != null)
            projectListActivityCallBack.agentSearchTechChange(charSequence);
    }

    @Override
    public void afterTextChanged(Editable editable) {

    }

    public void hideKeyBoardAutomatically() {
        Utils.hideKeyboard(this, binding.llMainLayout.edtFilterSearch);
    }

    public interface PropertyProjectListActivityCallBack {
        void agentSearchTechChange(CharSequence value);

        void agentClearSearchText();

        void agentSearchUsingEnterText();

        void agentSortAgentList();
    }

    @Override
    protected void onStart() {
        super.onStart();
        Utils.setLanguage(this);
    }
}
