package com.paya.paragon.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.StrikethroughSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.imageview.ShapeableImageView;
import com.paya.paragon.R;
import com.paya.paragon.activity.buy.PropertyListFragment;
import com.paya.paragon.api.BuyProperties.BuyPropertiesModel;
import com.paya.paragon.api.BuyProperties.ImagesList;
import com.paya.paragon.utilities.Utils;
import com.smarteist.autoimageslider.SliderView;
import com.smarteist.autoimageslider.SliderViewAdapter;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class PropertyListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    Context mContext;
    public  static ItemClickAdapterListener mOnClickListener;
    boolean mShowProgress;
    public List<BuyPropertiesModel> mPropertyLists;
    private String mImageBaseURLCompany;
    String mImageBaseUrl = "https://www.paya-realestate.com/public/uploads/property/images/medium/";





    public PropertyListAdapter(String imageBaseURLCompany, boolean showProgress, List<BuyPropertiesModel> propertyLists,
                                  Context con, ItemClickAdapterListener onClickListener) {
        this.mPropertyLists = propertyLists;
        this.mContext = con;
        this.mImageBaseURLCompany = imageBaseURLCompany;
        this.mShowProgress = showProgress;
        this.mOnClickListener = onClickListener;
    }



    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder;
        if (viewType == 0) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_buy_property_list_model, parent, false);
            viewHolder = new PropertyViewHolder(v);
        } else {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.progress_item, parent, false);
            viewHolder = new ProgressViewHolder(v);
        }







        return viewHolder;    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        if (holder instanceof PropertyViewHolder) {
            final PropertyViewHolder viewHolder = (PropertyViewHolder) holder;


            //Image Sliders

            viewHolder.sliderAdapter.add(mContext,mPropertyLists.get(position).getImages(),position);


            //Type Based
            if (mPropertyLists.get(position).getType().equals("Property")) {

                //Negotiable
                if (mPropertyLists.get(position).getIsNegotiable().equals("No")) {
                    viewHolder.tvNegotiable.setVisibility(View.INVISIBLE);
                } else {
                    viewHolder.tvNegotiable.setVisibility(View.VISIBLE);
                }

                //Property Name
                viewHolder.tvHeading.setText(mPropertyLists.get(position).getPropertyName());

                //Location
                viewHolder.tvLocation.setVisibility(View.VISIBLE);
                viewHolder.tvLocation.setText(mPropertyLists.get(position).getCityLocName());

                //Feature
                if ((mPropertyLists.get(position).getPropertyFeatured().equals("ON"))) {
                    viewHolder.tvFeature.setVisibility(View.VISIBLE);
                } else {
                    viewHolder.tvFeature.setVisibility(View.GONE);
                }

                //Fav(Agent Logo)
                Utils.loadUrlImage(viewHolder.ivFav, mImageBaseURLCompany
                        + mPropertyLists.get(position).getProjectUserCompanyLogo(), R.drawable.no_image_placeholder, false);

                //Posted On
                String postedDate = mContext.getString(R.string.posted_on_col) + " " + mPropertyLists.get(position).getPropertyAddedDate();
                viewHolder.tv_posted_on_date.setText(postedDate);

                //ImageCount
                if (mPropertyLists.get(position).getImageCount() != null && !mPropertyLists.get(position).getImageCount().equals("")) {
                    viewHolder.imageNumber.setText(mPropertyLists.get(position).getImageCount());
                }


            }
            else if(mPropertyLists.get(position).getType().equals("Unit")){

                //Negotiable
                viewHolder.tvNegotiable.setVisibility(View.INVISIBLE);

               //PropertyName
                viewHolder.tvHeading.setText(mPropertyLists.get(position).getProjectName());

                //Location
                viewHolder.tvLocation.setVisibility(View.GONE);

                //Feature
                if (mPropertyLists.get(position).getProjectFeatured().equals("ON")) {
                    viewHolder.tvFeature.setVisibility(View.VISIBLE);
                } else {
                    viewHolder.tvFeature.setVisibility(View.GONE);
                }


                //Posted on
                String postedDate = mContext.getString(R.string.posted_on_col) + " " + dateFormat(mPropertyLists.get(position).getProjectAddedDate());
                viewHolder.tv_posted_on_date.setText(postedDate);

                //Fav(Agent Logo)
                viewHolder.ivFav.setVisibility(View.GONE);

                //ImageCount
                if (mPropertyLists.get(position).getImageCount() != null && !mPropertyLists.get(position).getImageCount().equals("")) {
                    viewHolder.imageNumber.setText(mPropertyLists.get(position).getImageCount());
                } else viewHolder.imageNumber.setVisibility(View.GONE);

            }

            //Bedroom
            if (mPropertyLists.get(position).getProjectBedRoom() == null) {
                viewHolder.bed_ic_lay.setVisibility(View.GONE);
            } else {
                viewHolder.bed_ic_lay.setVisibility(View.VISIBLE);
                String propType = mPropertyLists.get(position).getProjectBedRoom() + " " + mContext.getString(R.string.bed);
                viewHolder.bed_textView.setText(propType);
            }

            //Property type
            if (mPropertyLists.get(position).getProjectTypeName() != null && !mPropertyLists.get(position).getProjectTypeName().equals("")) {
                viewHolder.apartment_textView.setText(mPropertyLists.get(position).getProjectTypeName());
                viewHolder.apartment_lay.setVisibility(View.VISIBLE);
                if (mPropertyLists.get(position).getPropertyTypeIcon() != null && !mPropertyLists.get(position).getPropertyTypeIcon().equals(""))
                    Utils.loadUrlImage(viewHolder.apartment_ic, mPropertyLists.get(position).getPropertyTypeIcon(), R.drawable.no_image_placeholder, false);
            } else viewHolder.apartment_lay.setVisibility(View.GONE);

            //Bathroom
            if (mPropertyLists.get(position).getPropertyBathRoom() != null && !mPropertyLists.get(position).getPropertyBathRoom().equals("")) {
                viewHolder.bath_textView.setText(String.format("%s %s", mPropertyLists.get(position).getPropertyBathRoom(), mContext.getString(R.string.bath)));
                viewHolder.bath_ic_lay.setVisibility(View.VISIBLE);
            } else viewHolder.bath_ic_lay.setVisibility(View.GONE);

            //Area
            if (mPropertyLists.get(position).getPropertySqrFeet() != null && !mPropertyLists.get(position).getPropertySqrFeet().equals("")) {
                viewHolder.area_textView.setText(String.format("%s %s", mPropertyLists.get(position).getPropertySqrFeet(), mContext.getString(R.string.meter_square)));
                viewHolder.area_ic_lay.setVisibility(View.VISIBLE);
            } else if (mPropertyLists.get(position).getPropertyPlotArea() != null && !mPropertyLists.get(position).getPropertyPlotArea().equals("")) {
                viewHolder.area_textView.setText(mPropertyLists.get(position).getPropertyPlotArea());
                viewHolder.area_ic_lay.setVisibility(View.VISIBLE);
            } else viewHolder.area_ic_lay.setVisibility(View.GONE);


            BuyPropertiesModel data = mPropertyLists.get(position);



            //Sold out status
            if (data.getPropertySoldOutStatus().equalsIgnoreCase("No")) {
                viewHolder.layout_sold_out.setVisibility(View.GONE);
            } else {
                viewHolder.layout_sold_out.setVisibility(View.VISIBLE);
                String soldOutDate = Utils.convertToDateOnlyFormat(data.getPropertySoldOutDate());
                viewHolder.tv_sold_out_date.setText(soldOutDate);
            }

            //Amount
            String amount = mContext.getString(R.string.currency_symbol) + " " + mPropertyLists.get(position).getPropertyPrice();
            if(data.getCurrencyID_5()!=null && !data.getCurrencyID_5().equalsIgnoreCase("0.00")){
                amount = mContext.getString(R.string.currency_symbol) + " " + data.getPropertyPrice();
            }else if(mPropertyLists.get(position).getCurrencyID_1()!=null && !data.getCurrencyID_1().equalsIgnoreCase("0.00")){
                amount = mContext.getString(R.string.iqd_currency_symbol) + " " + mPropertyLists.get(position).getPropertyPrice();
            }
            viewHolder.tvAmount.setText(amount);



            //Offer
            if (data.getIsOffer() != null && !data.getIsOffer().equals("") && data.getIsOffer().equalsIgnoreCase("Yes")) {
                if (data.getPropertyOfferDiscount() != null && !data.getPropertyOfferDiscount().equals("")) {
                    viewHolder.offerValue.setText(data.getPropertyOfferDiscount() + "% Off");
                    viewHolder.offerValue.setVisibility(View.VISIBLE);
                } else viewHolder.offerValue.setVisibility(View.GONE);

                if (data.getPropertyOfferPrice() != null && !data.getPropertyOfferPrice().equals("")) {

                    String propertyOfferPrice = mContext.getString(R.string.currency_symbol) + " " + mPropertyLists.get(position).getPropertyOfferPrice();
                    Spannable spannable = new SpannableString(propertyOfferPrice);
                    spannable.setSpan(new StrikethroughSpan(), 0, amount.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    spannable.setSpan(new ForegroundColorSpan(ContextCompat.getColor(
                            mContext,
                            R.color.gray
                    )), 0, amount.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
            } else {
                viewHolder.offerValue.setVisibility(View.GONE);
            }


            viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mOnClickListener.itemClick(view, position);
                }
            });


            viewHolder.ivFav.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
//                    mOnClickListener.itemFavClick(position);
                }
            });


            viewHolder.llAmount.setVisibility(View.VISIBLE);


            //shortlisted
            if (mPropertyLists.get(position).getPropertyFavourite().equals("1")) {
                viewHolder.ivShortList.setImageResource(R.drawable.menu_icon_like_on);
            } else {
                viewHolder.ivShortList.setImageResource(R.drawable.menu_icon_like_off);
            }

            viewHolder.ivShortList.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mOnClickListener.itemFavClick(position);
                }
            });



        }else if (holder instanceof ProgressViewHolder) {
            final ProgressViewHolder progressViewHolder = (ProgressViewHolder) holder;
            progressViewHolder.progressBar.setIndeterminate(true);

        }

    }

    @Override
    public int getItemCount() {
        int size;
        if (mShowProgress) {
            size = mPropertyLists.size() + 1;
        } else {
            size = mPropertyLists.size();
        }
        return size;
    }

    @Override
    public int getItemViewType(int position) {
        int a;
        if (position < mPropertyLists.size()) {
            a = 0;
        } else {
            a = 1;
        }
        return a;
    }

    public  class PropertyViewHolder extends RecyclerView.ViewHolder {
         public SliderAdapter sliderAdapter;
         public SliderView sliderView;

        ImageView apartment_ic;
        TextView tvAmount, tvNegotiable;
        TextView tvHeading, offerValue;
        TextView tvLocation;
        LinearLayout llMain;
        LinearLayout bath_ic_lay, bed_ic_lay, area_ic_lay, apartment_lay,indicator_lay;
        ImageView tvFeature;
        ImageView ivFav;
        TextView tv_posted_on_date;
        TextView tv_sold_out_date;
        LinearLayout layout_sold_out;
        LinearLayout llAmount;
        TextView imageNumber;
        ImageView ivShortList;

        TextView bath_textView, bed_textView, area_textView, apartment_textView;
        ViewPager imageVp;
        int mImageSize;




        public PropertyViewHolder(View v) {
            super(v);

            sliderView = itemView.findViewById(R.id.imageSlider);
            apartment_ic = itemView.findViewById(R.id.apartment_image);
            offerValue = itemView.findViewById(R.id.offerValue);
            tvAmount = itemView.findViewById(R.id.tv_amount);
            llAmount = itemView.findViewById(R.id.ll_amount);
            tvNegotiable = itemView.findViewById(R.id.tv_negotiable);
            tvHeading = itemView.findViewById(R.id.tv_heading);
            tvLocation = itemView.findViewById(R.id.tv_location);
            llMain = itemView.findViewById(R.id.ll_main);
            tvFeature = itemView.findViewById(R.id.tv_feature);
            ivFav = itemView.findViewById(R.id.iv_fav);
            tv_posted_on_date = itemView.findViewById(R.id.tv_posted_on_date);
            tv_sold_out_date = itemView.findViewById(R.id.sold_out_date);
            layout_sold_out = itemView.findViewById(R.id.layout_sold_out);
            imageNumber = itemView.findViewById(R.id.image_number);
            ivShortList = itemView.findViewById(R.id.iv_shortList);




            apartment_lay = itemView.findViewById(R.id.apartment_lay);
            apartment_textView = itemView.findViewById(R.id.apartment_textView);

            area_ic_lay = itemView.findViewById(R.id.area_ic_lay);
            area_textView = itemView.findViewById(R.id.area_textView);

            bed_ic_lay = itemView.findViewById(R.id.bed_ic_lay);
            bed_textView = itemView.findViewById(R.id.bed_textView);

            bath_ic_lay = itemView.findViewById(R.id.bath_ic_lay);
            bath_textView = itemView.findViewById(R.id.bath_textView);


            sliderView.setNestedScrollingEnabled(false);
            sliderAdapter = new SliderAdapter();
            sliderView.setSliderAdapter(sliderAdapter);
            sliderView.setAutoCycle(false);




        }
    }




    private class ProgressViewHolder extends RecyclerView.ViewHolder {
        public ProgressBar progressBar;

        public ProgressViewHolder(View v) {
            super(v);
            progressBar = (ProgressBar) v.findViewById(R.id.progressBar1);

        }
    }



    private class SliderViewHolder extends SliderViewAdapter.ViewHolder {
        ShapeableImageView imageView;

        public SliderViewHolder(View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.iv_cover);

        }
    }
    public class SliderAdapter extends SliderViewAdapter<SliderViewHolder> {
        Context context;
        int rcvPos;
        List<ImagesList> imagesLists;

        public SliderAdapter(){
        }
        public void  add(Context context, List<ImagesList> images, int position){
            this.context = context;
            this.imagesLists = (images);
            this.rcvPos = position;
            notifyDataSetChanged();
        }


        @Override
        public SliderViewHolder onCreateViewHolder(ViewGroup parent) {
            View view=LayoutInflater.from(parent.getContext()).inflate(R.layout.property_image_slider,null);
            return new SliderViewHolder(view);
        }

        @Override
        public void onBindViewHolder(SliderViewHolder viewHolder, int position) {
            Utils.loadUrlImage(viewHolder.imageView,mImageBaseUrl+imagesLists.get(position).getPropertyImageName(),R.drawable.no_image_placeholder,false);

            viewHolder.imageView.setOnClickListener(view -> mOnClickListener.itemClick(view,rcvPos));
        }

        @Override
        public int getCount() {
            return imagesLists.size();
        }
    }

    private String dateFormat(String time) {
        String inputPattern = "yyyy-MM-dd HH:mm:ss";
        String outputPattern = "MMM dd, yyyy";
        SimpleDateFormat inputFormat = new SimpleDateFormat(inputPattern, Locale.getDefault());
        SimpleDateFormat outputFormat = new SimpleDateFormat(outputPattern, Locale.getDefault());
        Date date;
        String strDate = null;

        try {
            date = inputFormat.parse(time);
            strDate = outputFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return strDate;
    }
    public interface ItemClickAdapterListener {
        void itemClick(View v, int position);

        void itemCallClick(int position);

        void itemShareClick(int position);

        void itemFavClick(int position);
    }
}
