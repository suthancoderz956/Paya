package com.paya.paragon.api.BuyProperties;



import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

@SuppressWarnings("unused")
public class BuyPropertiesListData {
    @SerializedName("searchPropertyCount") @Expose private String searchPropertyCount;
    @SerializedName("imageURL") @Expose private String imageURL;
    @SerializedName("companyProfileLogoUrl") @Expose private String companyProfileLogoUrl;
    @SerializedName("siteUrl") @Expose private String siteUrl;
    @SerializedName("propertyLists")  @Expose private List<BuyPropertiesModel> propertyLists;

    public String getSiteUrl() {
        return siteUrl;
    }

    public void setSiteUrl(String siteUrl) {
        this.siteUrl = siteUrl;
    }

    public String getSearchPropertyCount() {
        return searchPropertyCount;
    }

    public void setSearchPropertyCount(String searchPropertyCount) {
        this.searchPropertyCount = searchPropertyCount;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public List<BuyPropertiesModel> getPropertyLists() {
        return propertyLists;
    }

    public void setPropertyLists(List<BuyPropertiesModel> propertyLists) {
        this.propertyLists = propertyLists;
    }



    public String getCompanyProfileLogoUrl() {
        return companyProfileLogoUrl;
    }

    public void setCompanyProfileLogoUrl(String companyProfileLogoUrl) {
        this.companyProfileLogoUrl = companyProfileLogoUrl;
    }
}
