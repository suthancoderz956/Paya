package com.paya.paragon.api.listLocProject;



import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ListLocProjApi {
    @FormUrlEncoded
    @POST("index/listRegion")
    Call<ListLocProjectResponse> post(
            @Field("countryID") String countryID,
            @Field("keyword") String keyword,
            @Field("selectedCity") String selectedCity,
            @Field("location") String location
    );
}
