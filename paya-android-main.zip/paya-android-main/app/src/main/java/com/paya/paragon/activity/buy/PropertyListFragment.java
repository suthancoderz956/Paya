package com.paya.paragon.activity.buy;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.paya.paragon.PropertyProjectListActivity;
import com.paya.paragon.R;
import com.paya.paragon.activity.details.ActivityProjectDetails;
import com.paya.paragon.activity.details.ActivityPropertyDetails;
import com.paya.paragon.activity.login.ActivityLoginEmail;
import com.paya.paragon.adapter.BuyPropertyListAdapter;
import com.paya.paragon.adapter.PropertyListAdapter;
import com.paya.paragon.api.BuyProperties.BuyPropertiesListApi;
import com.paya.paragon.api.BuyProperties.BuyPropertiesListData;
import com.paya.paragon.api.BuyProperties.BuyPropertiesListResponse;
import com.paya.paragon.api.BuyProperties.BuyPropertiesModel;
import com.paya.paragon.api.addFavProperty.AddFavPropertyApi;
import com.paya.paragon.api.addFavProperty.AddFavPropertyResponse;
import com.paya.paragon.api.contactOwner.ContactOwnerPropertyApi;
import com.paya.paragon.api.contactOwner.ContactOwnerResponse;
import com.paya.paragon.base.BaseFragment;
import com.paya.paragon.commonClass.ApiLinks;
import com.paya.paragon.commonClass.GlobalValues;
import com.paya.paragon.utilities.CountryCode.CountryCodePicker;
import com.paya.paragon.utilities.DialogProgress;
import com.paya.paragon.utilities.PropertyProjectType;
import com.paya.paragon.utilities.SessionManager;
import com.paya.paragon.utilities.ShortListListener;
import com.paya.paragon.utilities.Utils;

import org.jetbrains.annotations.NotNull;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


@SuppressWarnings({"HardCodedStringLiteral", "unused"})
public class PropertyListFragment extends BaseFragment {

    public  static List<BuyPropertiesModel> propertyLists;
    List<BuyPropertiesModel> propertyListsRemain;
    String imageURLProperties;
    String imageBaseURLCompany;
    String countProperty;
    View view = null;
    RecyclerView recyclerList;
    TextView tvNoItem;
    private
    LinearLayoutManager mLayoutManager;
    BuyPropertyListAdapter buyPropertyListAdapter;
    BuyPropertyListAdapter buySuggestionListAdapter;
    boolean loadingMain;
    int pageCount = 0;
    public Dialog alertDialog;
    DialogProgress mLoadingDialog;
    String userId = "";
    String searchPropertyPurpose;
    public ShortListListener shortListListener;
    Context mContext;
    private String isMortgaged = "No";
    private IMapMarkerLocation iMapMarkerLocation;
    private PropertyProjectType type;

    public static PropertyListAdapter mPropertyListAdapter;


    public
    PropertyListFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        iMapMarkerLocation = (IMapMarkerLocation) context;
    }

    @SuppressLint("ValidFragment")
    public PropertyListFragment(List<BuyPropertiesModel> propertyLists, String imageURLProperties, String imageBaseURLCompany,
                                String countProperty, String searchPropertyPurpose, PropertyProjectType type) {
        this.propertyLists = propertyLists;
        this.imageURLProperties = imageURLProperties;
        this.countProperty = countProperty;
        this.imageBaseURLCompany = imageBaseURLCompany;
        this.searchPropertyPurpose = searchPropertyPurpose;
        this.type = type;

    }

    @Override
    public void onSaveInstanceState(@NonNull @NotNull Bundle outState) {
    }

    // TODO: Rename and change types and number of parameters
    public static PropertyListFragment newInstance(String param1, String param2) {
        return new PropertyListFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_buy_properties, container, false);
        Utils.changeLayoutOrientationDynamically(getActivity(), view);
        setData(getActivity(), propertyLists, imageURLProperties, imageBaseURLCompany, countProperty, searchPropertyPurpose, type);

        return view;
    }

    void setData(Context context, List<BuyPropertiesModel> propertyLists, String imageURLProperties, String imageBaseURLCompany,
                 String countProperty, String searchPropertyPurpose, PropertyProjectType type) {
        this.propertyLists = propertyLists;
        this.imageURLProperties = imageURLProperties;
        this.countProperty = countProperty;
        this.mContext = context;
        this.imageBaseURLCompany = imageBaseURLCompany;
        this.searchPropertyPurpose = searchPropertyPurpose;
        this.type = type;

        if (SessionManager.getLoginStatus(mContext)) {
            userId = SessionManager.getAccessToken(mContext);
        } else {
            userId = "";
        }

        if (view != null) {

            mLoadingDialog = new DialogProgress(mContext);
            recyclerList = view.findViewById(R.id.rv_list);
            tvNoItem = view.findViewById(R.id.tv_no_item);
            tvNoItem.setVisibility(View.GONE);

            mLayoutManager = new LinearLayoutManager(mContext, LinearLayoutManager.VERTICAL, false);
            recyclerList.setLayoutManager(mLayoutManager);

            ((SimpleItemAnimator) recyclerList.getItemAnimator()).setSupportsChangeAnimations(false);


            recyclerList.addOnScrollListener(new RecyclerView.OnScrollListener() {
                @Override
                public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                    super.onScrollStateChanged(recyclerView, newState);
                }

                @Override
                public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                    if (dy > 0) {
                        int visibleItemCount = mLayoutManager.getChildCount();
                        int totalItemCount = mLayoutManager.getItemCount();
                        int pastVisiblesItems = mLayoutManager.findFirstVisibleItemPosition();
                        if (loadingMain) {
                            if ((visibleItemCount + pastVisiblesItems) >= totalItemCount) {
                                showAnimatedProgressBar(getActivity());
                                loadingMain = false;
                                apiGetProperties();
                            }
                        }
                    }
                }
            });
            setList();
        }
    }

    public void setList() {
        pageCount = 1;
        if (propertyLists == null || propertyLists.size() == 0) {
            tvNoItem.setVisibility(View.VISIBLE);
        } else {
            boolean loadMore;
            if (propertyLists.size() == 20) {
                loadMore = true;
                loadingMain = true;
            } else {
                loadMore = false;
                loadingMain = false;
            }

            //Commented By Lavanya
           /* Log.d("imageUrl",imageURLProperties);
            buyPropertyListAdapter = new BuyPropertyListAdapter(imageURLProperties, imageBaseURLCompany, loadMore,
                    propertyLists, getActivity(), new BuyPropertyListAdapter.ItemClickAdapterListener() {
                @Override
                public void itemClick(View v, int position) {
                    String type = propertyLists.get(position).getType();
                    String itemId;
                    if (type.equals("Property")) {
                        itemId = propertyLists.get(position).getPropertyID();
                        Intent intent = new Intent(getActivity(), ActivityPropertyDetails.class);
                        intent.putExtra("propertyID", itemId);
                        intent.putExtra("position", position);
                        intent.putExtra(Utils.TYPE, PropertyListFragment.this.type);
                        intent.putExtra("purpose", searchPropertyPurpose);
                        startActivity(intent);
                    } else if (type.equals("Unit")) {
                        itemId = propertyLists.get(position).getProjectID();
                        Intent intent = new Intent(getActivity(), ActivityProjectDetails.class);
                        intent.putExtra(Utils.TYPE, PropertyListFragment.this.type);
                        intent.putExtra("projectID", itemId);
                        intent.putExtra("position", position);
                        intent.putExtra("purpose", searchPropertyPurpose);
                        startActivity(intent);
                    }

                }

                @Override
                public void itemCallClick(int position) {
                    String type = propertyLists.get(position).getType();
                    String itemId = null;
                    if (type.equals("Property")) {
                        itemId = propertyLists.get(position).getPropertyID();
                    } else if (type.equals("Unit")) {
                        itemId = propertyLists.get(position).getProjectID();
                    }
                    alertContactOwner(getActivity(), position, itemId);
                }

                @Override
                public void itemShareClick(int position) {

                    String shareBody = PropertyProjectListActivity.siteUrl + "" + propertyLists.get(position).getLink();
                    Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                    sharingIntent.setType("text/plain");
                    sharingIntent.putExtra(Intent.EXTRA_SUBJECT, "Subject Here");
                    sharingIntent.putExtra(Intent.EXTRA_TEXT, shareBody);
                    startActivity(Intent.createChooser(sharingIntent, "share"));
                }

                @Override
                public void itemFavClick(int position) {
                    navigateToAgentDetails();
                }
            });
            recyclerList.setAdapter(buyPropertyListAdapter);*/


            mPropertyListAdapter = new PropertyListAdapter(imageBaseURLCompany, loadMore, propertyLists, getActivity(), new PropertyListAdapter.ItemClickAdapterListener() {
                @Override
                public void itemClick(View v, int position) {
                    String type = propertyLists.get(position).getType();
                    String itemId;
                    Log.d("id",propertyLists.get(position).getPropertyID()+" "+SessionManager.getUserId(requireContext()) );

                    if (type.equals("Property")) {
                        itemId = propertyLists.get(position).getPropertyID();
                        Intent intent = new Intent(getActivity(), ActivityPropertyDetails.class);
                        intent.putExtra("propertyID", itemId);
                        intent.putExtra("position", position);
                        intent.putExtra(Utils.TYPE, PropertyListFragment.this.type);
                        intent.putExtra("purpose", searchPropertyPurpose);
                        startActivity(intent);
                    } else if (type.equals("Unit")) {
                        itemId = propertyLists.get(position).getProjectID();
                        Intent intent = new Intent(getActivity(), ActivityProjectDetails.class);
                        intent.putExtra(Utils.TYPE, PropertyListFragment.this.type);
                        intent.putExtra("projectID", itemId);
                        intent.putExtra("position", position);
                        intent.putExtra("purpose", searchPropertyPurpose);
                        startActivity(intent);
                    }
                }

                @Override
                public void itemCallClick(int position) {
                    String type = propertyLists.get(position).getType();
                    String itemId = null;
                    if (type.equals("Property")) {
                        itemId = propertyLists.get(position).getPropertyID();

                    } else if (type.equals("Unit")) {
                        itemId = propertyLists.get(position).getProjectID();
                    }
                    alertContactOwner(getActivity(), position, itemId);
                }

                @Override
                public void itemShareClick(int position) {
                    String shareBody = PropertyProjectListActivity.siteUrl + "" + propertyLists.get(position).getLink();
                    Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                    sharingIntent.setType("text/plain");
                    sharingIntent.putExtra(Intent.EXTRA_SUBJECT, "Subject Here");
                    sharingIntent.putExtra(Intent.EXTRA_TEXT, shareBody);
                    startActivity(Intent.createChooser(sharingIntent, "share"));
                }

                @Override
                public void itemFavClick(int position) {
                    initiateFavourite(position);
//                    navigateToAgentDetails();

                }
            });
            recyclerList.setAdapter(mPropertyListAdapter);
//            ((SimpleItemAnimator) recyclerList.getItemAnimator()).setSupportsChangeAnimations(false);

        }
    }

    private void navigateToAgentDetails() {

    }

    public void setRemain() {
        pageCount++;
        boolean loadMore;
        int lastPosition = 0;
        if (propertyListsRemain == null || propertyListsRemain.size() == 0) {
            loadMore = false;
            loadingMain = false;
        } else {
            Log.e("Remain  List Size", propertyListsRemain.size() + "");
            if (propertyListsRemain.size() == 20) {
                loadMore = true;
                loadingMain = true;
            } else {
                loadMore = false;
                loadingMain = false;
            }
            lastPosition = propertyLists.size();
            propertyLists.addAll(propertyListsRemain);

        }
        if (loadMore) {
//            buyPropertyListAdapter.notifyDataSetChanged();
            mPropertyListAdapter.notifyDataSetChanged();
//            ((SimpleItemAnimator) recyclerList.getItemAnimator()).setSupportsChangeAnimations(false);



        } else {
            //Commented by Lavanya
                /*buyPropertyListAdapter = new BuyPropertyListAdapter(imageURLProperties, imageBaseURLCompany, false,
                    propertyLists, getActivity(), new BuyPropertyListAdapter.ItemClickAdapterListener() {
                @Override
                public void itemClick(View v, int position) {
                    String type = propertyLists.get(position).getType();
                    String itemId;
                    if (type.equals("Property")) {
                        itemId = propertyLists.get(position).getPropertyID();
                        Intent intent = new Intent(getActivity(),
                                ActivityPropertyDetails.class);
                        intent.putExtra("propertyID", itemId);
                        intent.putExtra("position", position);
                        intent.putExtra("purpose", searchPropertyPurpose);
                        startActivity(intent);
                    } else if (type.equals("Unit")) {
                        itemId = propertyLists.get(position).getProjectID();
                        Intent intent = new Intent(getActivity(),
                                ActivityProjectDetails.class);
                        intent.putExtra("projectID", itemId);
                        intent.putExtra("position", position);
                        intent.putExtra("purpose", searchPropertyPurpose);
                        startActivity(intent);
                    }
                }

                @Override
                public void itemCallClick(int position) {
                    String type = propertyLists.get(position).getType();
                    String itemId = null;
                    if (type.equals("Property")) {
                        itemId = propertyLists.get(position).getPropertyID();
                    } else if (type.equals("Unit")) {
                        itemId = propertyLists.get(position).getProjectID();
                    }
                    alertContactOwner(getActivity(), position, itemId);
                }

                @Override
                public void itemShareClick(int position) {
                    String shareBody = PropertyProjectListActivity.siteUrl + "" + propertyLists.get(position).getLink();
                    Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                    sharingIntent.setType("text/plain");
                    sharingIntent.putExtra(Intent.EXTRA_SUBJECT, "Subject Here");
                    sharingIntent.putExtra(Intent.EXTRA_TEXT, shareBody);
                    startActivity(Intent.createChooser(sharingIntent, "share"));
                }

                @Override
                public void itemFavClick(int position) {
                    //initiateFavourite(position);
                    navigateToAgentDetails();
                }
            });
            recyclerList.setAdapter(buyPropertyListAdapter);*/
            mPropertyListAdapter = new PropertyListAdapter(imageBaseURLCompany, loadMore, propertyLists, getActivity(), new PropertyListAdapter.ItemClickAdapterListener() {
                @Override
                public void itemClick(View v, int position) {
                    String type = propertyLists.get(position).getType();
                    Log.d("id",propertyLists.get(position).getPropertyID()+" "+SessionManager.getUserId(requireContext()) );

                    String itemId;
                    if (type.equals("Property")) {
                        itemId = propertyLists.get(position).getPropertyID();
                        Intent intent = new Intent(getActivity(),
                                ActivityPropertyDetails.class);
                        intent.putExtra("propertyID", itemId);
                        intent.putExtra("position", position);
                        intent.putExtra("purpose", searchPropertyPurpose);
                        startActivity(intent);
                    } else if (type.equals("Unit")) {
                        itemId = propertyLists.get(position).getProjectID();
                        Intent intent = new Intent(getActivity(),
                                ActivityProjectDetails.class);
                        intent.putExtra("projectID", itemId);
                        intent.putExtra("position", position);
                        intent.putExtra("purpose", searchPropertyPurpose);
                        startActivity(intent);
                    }
                }

                @Override
                public void itemCallClick(int position) {
                    String type = propertyLists.get(position).getType();
                    String itemId = null;
                    if (type.equals("Property")) {
                        itemId = propertyLists.get(position).getPropertyID();
                    } else if (type.equals("Unit")) {
                        itemId = propertyLists.get(position).getProjectID();
                    }
                    alertContactOwner(getActivity(), position, itemId);
                }

                @Override
                public void itemShareClick(int position) {
                    String shareBody = PropertyProjectListActivity.siteUrl + "" + propertyLists.get(position).getLink();
                    Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                    sharingIntent.setType("text/plain");
                    sharingIntent.putExtra(Intent.EXTRA_SUBJECT, "Subject Here");
                    sharingIntent.putExtra(Intent.EXTRA_TEXT, shareBody);
                    startActivity(Intent.createChooser(sharingIntent, "share"));
                }

                @Override
                public void itemFavClick(int position) {
                    initiateFavourite(position);
//                    navigateToAgentDetails();
                }
            });
            recyclerList.setAdapter(mPropertyListAdapter);
//            ((SimpleItemAnimator) recyclerList.getItemAnimator()).setSupportsChangeAnimations(false);
            mLayoutManager.scrollToPosition(lastPosition);
        }
    }
    private void initiateFavourite(int position) {
        if (SessionManager.getLoginStatus(getActivity())) {
            String type = propertyLists.get(position).getType();
                String PropertyID = propertyLists.get(position).getPropertyID();
                apiFavProperty(PropertyID, userId, position);
        } else {
            startActivity(new Intent(getActivity(), ActivityLoginEmail.class));
        }
    }

    public void setListener(ShortListListener listener) {
        shortListListener = listener;
    }


    //TODO API Calls
    //get properties
    public void apiGetProperties() {
        Log.e("pageCount", pageCount + "");
        String location_id = "2";
        if (!SessionManager.getLocationId(mContext).equals("-1"))
            location_id = SessionManager.getLocationId(mContext);


        ApiLinks.getClient().create(BuyPropertiesListApi.class).post(userId,
                "" + SessionManager.getLanguageID(mContext),
                location_id,
                searchPropertyPurpose, pageCount + "",
                "Property",
                GlobalValues.selectedSortValue,
                GlobalValues.selectedMinPrice,
                GlobalValues.selectedMaxPrice,
                GlobalValues.selectedPropertyTypeID,
                GlobalValues.countryID,
                GlobalValues.selectedBedroomsNumber,
                GlobalValues.selectedFurnishedStaticValue,
                GlobalValues.selectedRegionId,
                "",
                "",
                "",
                "",
                "").enqueue(new Callback<BuyPropertiesListResponse>() {
            @Override
            public void onResponse(@NonNull Call<BuyPropertiesListResponse> call,
                                   @NonNull Response<BuyPropertiesListResponse> response) {
                if (response.isSuccessful()) {
                    String status = response.body().getResponse();
                    if (status.equals("Success")) {
                        BuyPropertiesListData data = response.body().getData();
                        propertyListsRemain = data.getPropertyLists();
                        iMapMarkerLocation.setPropertyListForMap(propertyListsRemain);
                        dismissAnimatedProgressBar();

                        setRemain();
                    }
                } else {
                    Log.e("Status", "Failed");
                }
            }

            @Override
            public void onFailure(@NonNull Call<BuyPropertiesListResponse> call, @NonNull Throwable t) {
            }
        });
    }

    //Fav Property
    public void apiFavProperty(String id, String userID, final int position) {
        mLoadingDialog.show();
        ApiLinks.getClient().create(AddFavPropertyApi.class)
                .post(id, userID,SessionManager.getLanguageID(getActivity()))
                .enqueue(new Callback<AddFavPropertyResponse>() {
                    @Override
                    public void onResponse(@NonNull Call<AddFavPropertyResponse> call,
                                           @NonNull Response<AddFavPropertyResponse> response) {
                        if (response.isSuccessful()) {
                            String message = response.body().getMessage();
                            if (response.body().getResponse().equalsIgnoreCase("Success")) {
                                String propertyFavourite = propertyLists.get(position).getPropertyFavourite();
                                if (propertyFavourite.equals("1")) {
                                    propertyLists.get(position).setPropertyFavourite("0");
                                    shortListListener.decreaseClick();
                                } else {
                                    propertyLists.get(position).setPropertyFavourite("1");
                                    shortListListener.increaseClick();
                                }
//                                buyPropertyListAdapter.notifyItemChanged(position);
                                mPropertyListAdapter.notifyItemChanged(position);
                                mLoadingDialog.dismiss();
                                Log.e("Status", "status");
                            } else {
                                mLoadingDialog.dismiss();
                                Toast.makeText(getContext(), getString(R.string.failed_to_shortlist), Toast.LENGTH_SHORT).show();
                            }
                            Log.e("Status", "status1");
                        } else {
                            Log.e("Status", "Failed2");
                            mLoadingDialog.dismiss();
                            Toast.makeText(getContext(), getString(R.string.failed_to_shortlist), Toast.LENGTH_SHORT).show();
                        }
                        Log.e("Status", "status3");
                    }

                    @Override
                    public void onFailure(@NonNull Call<AddFavPropertyResponse> call, @NonNull Throwable t) {
                        Log.e("Status", t.getMessage());
                        mLoadingDialog.dismiss();
                        Toast.makeText(getContext(), getString(R.string.failed_to_shortlist), Toast.LENGTH_SHORT).show();
                        Log.e("Status", "status4");
                    }
                });
    }

    private void postContactOwner(FragmentActivity activity, final Dialog alertDialog, String strName, String strEmail,
                                  String strPhone, String strCountryCode, int position, String itemId) {
        if (!Utils.NoInternetConnection(activity)) {
            alertDialog.dismiss();
            mLoadingDialog.show();
            ApiLinks.getClient().create(ContactOwnerPropertyApi.class)
                    .post(SessionManager.getAccessToken(activity),
                            itemId, "Property", "Listing",
                            strEmail, strName, strPhone, "", strCountryCode, isMortgaged)
                    .enqueue(new Callback<ContactOwnerResponse>() {
                        @Override
                        public void onResponse(Call<ContactOwnerResponse> call, Response<ContactOwnerResponse> response) {
                            try {
                                if (response.isSuccessful()) {
                                    String message = response.body().getResponse();
                                    Log.e("postContactOwner", message);
                                    int code = response.body().getCode();
                                    if (code == 4000) {
                                        //alertDialog.dismiss();
                                        alertSuccess(getActivity(), getResources().getString(R.string.thank_you_for_contact),
                                                getResources().getString(R.string.contact_owner_success_message));
                                    } else {
                                        alertDialog.dismiss();
                                        Log.e("postContactOwner", response.body().getMessage());
                                        Toast.makeText(getActivity(), response.body().getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                    mLoadingDialog.dismiss();
                                } else {
                                    alertDialog.dismiss();
                                    Toast.makeText(getActivity(), getString(R.string.no_response), Toast.LENGTH_SHORT).show();
                                    mLoadingDialog.dismiss();
                                }
                            } catch (Exception e) {
                                FirebaseCrashlytics.getInstance().recordException(e);
                                e.printStackTrace();
                            }
                        }

                        @Override
                        public void onFailure(Call<ContactOwnerResponse> call, Throwable t) {
                            alertDialog.dismiss();
                            Toast.makeText(getActivity(), t.getMessage(), Toast.LENGTH_SHORT).show();
                            mLoadingDialog.dismiss();
                            alertDialog.dismiss();
                        }
                    });
        } else {
            alertDialog.dismiss();
            Utils.showAlertNoInternet(activity);
        }
    }

    //TODO Alert
    @SuppressLint("SetTextI18n")
    private void alertContactOwner(final FragmentActivity activity, final int position, final String itemId) {
        alertDialog = new Dialog(activity);
        alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LayoutInflater factory = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        assert factory != null;
        @SuppressLint("InflateParams") final View alert_layout = factory.inflate(R.layout.alert_contact_agent_popup, null);
        ImageView close = alert_layout.findViewById(R.id.close_contact_owner);
        final EditText fullName = alert_layout.findViewById(R.id.editText_user_full_name_contact_owner);
        final EditText email = alert_layout.findViewById(R.id.editText_user_email_address_contact_owner);
        final EditText phone = alert_layout.findViewById(R.id.editText_phone_contact_owner);
        final CountryCodePicker codePicker = alert_layout.findViewById(R.id.country_code_contact_owner);
        final EditText message = alert_layout.findViewById(R.id.editText_user_message_contact_owner);
        TextView submit = alert_layout.findViewById(R.id.button_submit_contact_owner);
        final CheckBox cbMortgage = alert_layout.findViewById(R.id.checkBox_info_mortgage_make_an_offer);
        final CheckBox cbTerms = alert_layout.findViewById(R.id.checkBox_terms_conditions_make_an_offer);


        message.setVisibility(View.GONE);
        final TextView title = alert_layout.findViewById(R.id.title);
        title.setText("Contact Owner");
        if (SessionManager.getLoginStatus(activity)) {
            fullName.setText(SessionManager.getFullName(activity));
            email.setText(SessionManager.getEmail(activity));
            phone.setText(SessionManager.getPhone(activity));
            codePicker.setCountryForNameCode(SessionManager.getCountryCode(activity));
        }

        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String strCountryCode = codePicker.getSelectedCountryNameCode().toLowerCase();
                String strName = fullName.getText().toString();
                String strEmail = email.getText().toString();
                String strPhone = phone.getText().toString();
                String alertValidation = Utils.validateContactPopUp(getActivity(), strName, strEmail, strPhone, cbTerms);
                if (cbMortgage.isChecked()) {
                    isMortgaged = "Yes";
                }

                if (alertValidation.equals("ok")) {
                    if (!Utils.NoInternetConnection(activity)) {
                        postContactOwner(activity, alertDialog, strName, strEmail, strPhone, strCountryCode, position, itemId);
                    } else {
                        Toast.makeText(activity, getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    if (!alertValidation.equalsIgnoreCase("notOk")) {
                        Toast.makeText(getActivity(), alertValidation, Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        alertDialog.setContentView(alert_layout);
        //noinspection ConstantConditions
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        alertDialog.setCanceledOnTouchOutside(true);
        alertDialog.show();
    }

    private void alertSuccess(FragmentActivity activity, String successTitle, String successMessage) {
        alertDialog = new Dialog(activity);
        alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LayoutInflater factory = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        assert factory != null;
        @SuppressLint("InflateParams") final View alert_layout = factory.inflate(R.layout.alert_success_popup, null);
        ImageView close = alert_layout.findViewById(R.id.close_success_dialog);
        TextView title = alert_layout.findViewById(R.id.title_alert_success_popup);
        TextView message = alert_layout.findViewById(R.id.message_alert_success_popup);
        title.setText(successTitle);
        message.setText(successMessage);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });
        alertDialog.setContentView(alert_layout);
        //noinspection ConstantConditions
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        alertDialog.setCanceledOnTouchOutside(true);
        alertDialog.show();
    }


}
