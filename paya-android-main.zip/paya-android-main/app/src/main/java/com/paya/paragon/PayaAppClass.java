package com.paya.paragon;

import android.annotation.SuppressLint;
import android.app.Application;
import android.provider.Settings;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.paya.paragon.utilities.SessionManager;


public class PayaAppClass extends Application {

    public static PayaAppClass appInstance;

    @SuppressLint("HardwareIds")
    @Override
    public void onCreate() {
        super.onCreate();
        appInstance = this;
        try {
            FirebaseInstanceId.getInstance().getInstanceId().addOnSuccessListener(new OnSuccessListener<InstanceIdResult>() {
                @Override
                public void onSuccess(InstanceIdResult instanceIdResult) {
                    String token = instanceIdResult.getToken();
                    SessionManager.setDeviceTokenForFCM(appInstance, token);
                }
            });
        } catch (Exception e) {
            FirebaseCrashlytics.getInstance().recordException(e);
        }

    }

    public static PayaAppClass getAppInstance() {
        if (appInstance == null) {
            appInstance = new PayaAppClass();
        }
        return appInstance;
    }
}
