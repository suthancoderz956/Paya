package com.paya.paragon.api.listLocProject;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ListLocProjectData {

    @SerializedName("location") @Expose private List<RegionDataChild> location;
    @SerializedName("projects") @Expose private List<RegionDataChild> projects;
    @SerializedName("SubCommunity") @Expose private List<RegionDataChild> SubCommunity;


    public List<RegionDataChild> getSubCommunity() { return SubCommunity; }

    public void setSubCommunity(List<RegionDataChild> subCommunity) { SubCommunity = subCommunity; }

    public List<RegionDataChild> getLocation() {
        return location;
    }

    public void setLocation(List<RegionDataChild> location) {
        this.location = location;
    }

    public List<RegionDataChild> getProjects() {
        return projects;
    }

    public void setProjects(List<RegionDataChild> projects) {
        this.projects = projects;
    }
}
