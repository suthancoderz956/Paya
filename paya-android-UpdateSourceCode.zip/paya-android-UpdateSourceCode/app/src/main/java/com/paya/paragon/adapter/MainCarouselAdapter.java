package com.paya.paragon.adapter;

import android.content.Context;
import android.transition.Slide;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;
import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.tabs.TabLayout;
import com.paya.paragon.R;
import com.paya.paragon.utilities.ExtendedViewPager;
import com.paya.paragon.utilities.Utils;

import java.util.ArrayList;

public class MainCarouselAdapter extends RecyclerView.Adapter<MainCarouselAdapter.MainCarouselViewHolder> {

    private Context context;
    ArrayList<String> imageList;

    public MainCarouselAdapter(Context context, ArrayList<String> imageList) {
        this.context = context;
        this.imageList = imageList;
    }

    @Override
    public MainCarouselAdapter.MainCarouselViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_horizontal_carousel, parent, false);
        return new MainCarouselAdapter.MainCarouselViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final MainCarouselAdapter.MainCarouselViewHolder holder, final int position) {
        Utils.loadUrlImage(holder.img_carousel, imageList.get(position), R.drawable.no_image_placeholder, false);
    }

    public int getItemCount() {
        return imageList.size();
    }

    static class MainCarouselViewHolder extends RecyclerView.ViewHolder {
        //ExtendedViewPager imageViewPager;
        //TabLayout tab_layout;
        ShapeableImageView img_carousel;

        MainCarouselViewHolder(View itemView) {
            super(itemView);
           // this.imageViewPager = itemView.findViewById(R.id.imageViewPager);
            //this.tab_layout = itemView.findViewById(R.id.tab_layout);
            this.img_carousel = itemView.findViewById(R.id.img_carousel);
        }
    }
}
