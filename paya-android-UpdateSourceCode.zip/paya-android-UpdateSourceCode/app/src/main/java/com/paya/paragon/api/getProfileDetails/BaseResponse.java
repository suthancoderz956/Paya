package com.paya.paragon.api.getProfileDetails;

public class BaseResponse {
    String response;
    String message;
    // String code;

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


}
