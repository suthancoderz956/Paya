package com.paya.paragon.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.imageview.ShapeableImageView;
import com.paya.paragon.R;
import com.paya.paragon.utilities.Utils;

import java.util.ArrayList;

public class CarouselAdapter
        extends RecyclerView.Adapter<CarouselAdapter.MyViewHolder> {

    private Context context;
    ArrayList<String> list;

    public CarouselAdapter(Context context, ArrayList<String> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.row_item_caroasel, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Utils.loadUrlImage(holder.img_logo, list.get(position), R.drawable.no_image_placeholder, false);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvName;
//        ImageView img_logo;
        ShapeableImageView img_logo;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            img_logo = itemView.findViewById(R.id.img_logo);
        }
    }
}
